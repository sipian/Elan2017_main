/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.5.0",
   minimumCompatibleVersion: "1.5.0",
   build: "1.5.0.217",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'creat_btn2',
            type:'image',
            rect:['0%','6.1%','11.7%','6.3%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"creat_btn.png",'0px','0px']
         },
         {
            id:'hospi_btn_1',
            type:'image',
            rect:['0%','12.8%','11.7%','6.3%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"hospi_btn_1.png",'0px','0px']
         },
         {
            id:'markt_btn',
            type:'image',
            rect:['0%','19.7%','11.7%','6.3%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"markt_btn.png",'0px','0px']
         },
         {
            id:'finan_btn',
            type:'image',
            rect:['0%','26%','11.7%','6.3%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"finan_btn.png",'0px','0px']
         },
         {
            id:'events_btn',
            type:'image',
            rect:['0%','32.2%','11.7%','6.3%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"events_btn.png",'0px','0px']
         },
         {
            id:'optrans_btn',
            type:'image',
            rect:['0%','37.4%','11.7%','7.2%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"optrans_btn.png",'0px','0px']
         },
         {
            id:'overall_btn',
            type:'image',
            rect:['0%','43.9%','11.7%','7.2%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"overall_btn.png",'0px','0px']
         },
         {
            id:'opCoord',
            type:'image',
            rect:['44.9%','-18.1%','10.2%','18.1%','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"opCoord.png",'0px','0px']
         },
         {
            id:'opCoord2',
            type:'image',
            rect:['44.9%','-18.1%','10.2%','18.1%','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"opCoord2.png",'0px','0px']
         },
         {
            id:'opCore',
            type:'image',
            rect:['44.9%','-18.1%','10.2%','18.1%','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"opCore.png",'0px','0px']
         },
         {
            id:'securityCood',
            type:'image',
            rect:['44.9%','-18.1%','10.2%','18.1%','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"securityCood.png",'0px','0px']
         },
         {
            id:'transportCoord',
            type:'image',
            rect:['44.9%','-18.1%','10.2%','18.1%','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"transportCoord.png",'0px','0px']
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_overall_btn}": [
            ["style", "top", '43.88%'],
            ["style", "height", '7.22%'],
            ["style", "left", '0%'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '11.72%']
         ],
         "${_hospi_btn_1}": [
            ["style", "top", '12.78%'],
            ["style", "height", '6.25%'],
            ["style", "left", '0%'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '11.72%']
         ],
         "${_markt_btn}": [
            ["style", "top", '19.71%'],
            ["style", "height", '6.25%'],
            ["style", "left", '0%'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '11.72%']
         ],
         "${_opCoord}": [
            ["style", "top", '-18.06%'],
            ["style", "opacity", '1'],
            ["style", "left", '44.92%']
         ],
         "${_opCoord2}": [
            ["style", "top", '-18.06%'],
            ["style", "opacity", '1'],
            ["style", "left", '44.92%']
         ],
         "${_transportCoord}": [
            ["style", "top", '-18.06%'],
            ["style", "opacity", '1'],
            ["style", "left", '44.92%']
         ],
         "${_events_btn}": [
            ["style", "top", '32.22%'],
            ["style", "height", '6.25%'],
            ["style", "left", '0%'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '11.72%']
         ],
         "${_opCore}": [
            ["style", "top", '-18.06%'],
            ["style", "opacity", '1'],
            ["style", "left", '44.92%']
         ],
         "${_finan_btn}": [
            ["style", "top", '25.97%'],
            ["style", "height", '6.25%'],
            ["style", "left", '0%'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '11.72%']
         ],
         "${_Stage}": [
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "min-width", '350px'],
            ["style", "overflow", 'hidden'],
            ["style", "height", '100%'],
            ["style", "width", '100%']
         ],
         "${_optrans_btn}": [
            ["style", "top", '37.36%'],
            ["style", "height", '7.22%'],
            ["style", "left", '0%'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '11.72%']
         ],
         "${_creat_btn2}": [
            ["style", "top", '6.11%'],
            ["style", "height", '6.25%'],
            ["style", "left", '0%'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '11.72%']
         ],
         "${_securityCood}": [
            ["style", "top", '-18.06%'],
            ["style", "opacity", '1'],
            ["style", "left", '44.92%']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 2467,
         autoPlay: true,
         labels: {
            "in": 200,
            "shortIn": 600,
            "out": 1467
         },
         timeline: [
            { id: "eid944", tween: [ "style", "${_opCore}", "opacity", '1', { fromValue: '1'}], position: 600, duration: 0 },
            { id: "eid963", tween: [ "style", "${_opCore}", "opacity", '1', { fromValue: '1'}], position: 1200, duration: 0 },
            { id: "eid966", tween: [ "style", "${_opCore}", "opacity", '1', { fromValue: '1'}], position: 1467, duration: 0 },
            { id: "eid989", tween: [ "style", "${_opCore}", "opacity", '1', { fromValue: '1'}], position: 1733, duration: 0 },
            { id: "eid1000", tween: [ "style", "${_opCore}", "opacity", '1', { fromValue: '1'}], position: 1933, duration: 0 },
            { id: "eid1029", tween: [ "style", "${_opCore}", "opacity", '0', { fromValue: '1'}], position: 2133, duration: 334 },
            { id: "eid954", tween: [ "style", "${_securityCood}", "left", '32.89%', { fromValue: '44.92%'}], position: 600, duration: 600 },
            { id: "eid981", tween: [ "style", "${_securityCood}", "left", '26.24%', { fromValue: '32.89%'}], position: 1467, duration: 266 },
            { id: "eid990", tween: [ "style", "${_securityCood}", "left", '67.27%', { fromValue: '26.25%'}], position: 1733, duration: 200 },
            { id: "eid1007", tween: [ "style", "${_securityCood}", "left", '68.36%', { fromValue: '67.27%'}], position: 1933, duration: 200 },
            { id: "eid1023", tween: [ "style", "${_securityCood}", "left", '0%', { fromValue: '68.36%'}], position: 2133, duration: 334 },
            { id: "eid952", tween: [ "style", "${_transportCoord}", "left", '6.21%', { fromValue: '44.92%'}], position: 600, duration: 600 },
            { id: "eid983", tween: [ "style", "${_transportCoord}", "left", '26.25%', { fromValue: '6.25%'}], position: 1467, duration: 266 },
            { id: "eid994", tween: [ "style", "${_transportCoord}", "left", '67.27%', { fromValue: '26.25%'}], position: 1733, duration: 200 },
            { id: "eid1005", tween: [ "style", "${_transportCoord}", "left", '25.94%', { fromValue: '67.27%'}], position: 1933, duration: 200 },
            { id: "eid1017", tween: [ "style", "${_transportCoord}", "left", '94.17%', { fromValue: '25.94%'}], position: 2133, duration: 334 },
            { id: "eid948", tween: [ "style", "${_securityCood}", "top", '20.42%', { fromValue: '-18.06%'}], position: 600, duration: 267 },
            { id: "eid955", tween: [ "style", "${_securityCood}", "top", '57.92%', { fromValue: '20.42%'}], position: 867, duration: 333 },
            { id: "eid982", tween: [ "style", "${_securityCood}", "top", '7.92%', { fromValue: '57.92%'}], position: 1467, duration: 266 },
            { id: "eid991", tween: [ "style", "${_securityCood}", "top", '60.69%', { fromValue: '7.92%'}], position: 1733, duration: 200 },
            { id: "eid1006", tween: [ "style", "${_securityCood}", "top", '7.92%', { fromValue: '60.69%'}], position: 1933, duration: 200 },
            { id: "eid1024", tween: [ "style", "${_securityCood}", "top", '105.21%', { fromValue: '7.92%'}], position: 2133, duration: 334 },
            { id: "eid945", tween: [ "style", "${_opCoord}", "opacity", '1', { fromValue: '1'}], position: 600, duration: 0 },
            { id: "eid960", tween: [ "style", "${_opCoord}", "opacity", '1', { fromValue: '1'}], position: 1200, duration: 0 },
            { id: "eid978", tween: [ "style", "${_opCoord}", "opacity", '1', { fromValue: '1'}], position: 1467, duration: 0 },
            { id: "eid1030", tween: [ "style", "${_opCoord}", "opacity", '0', { fromValue: '1'}], position: 2133, duration: 334 },
            { id: "eid958", tween: [ "style", "${_opCoord}", "left", '84.5%', { fromValue: '44.92%'}], position: 600, duration: 600 },
            { id: "eid987", tween: [ "style", "${_opCoord}", "left", '67.27%', { fromValue: '84.53%'}], position: 1467, duration: 266 },
            { id: "eid992", tween: [ "style", "${_opCoord}", "left", '26.25%', { fromValue: '67.27%'}], position: 1733, duration: 200 },
            { id: "eid1004", tween: [ "style", "${_opCoord}", "left", '25.97%', { fromValue: '26.25%'}], position: 1933, duration: 200 },
            { id: "eid1026", tween: [ "style", "${_opCoord}", "left", '72.97%', { fromValue: '25.94%'}], position: 2133, duration: 334 },
            { id: "eid951", tween: [ "style", "${_transportCoord}", "top", '20.42%', { fromValue: '-18.06%'}], position: 600, duration: 267 },
            { id: "eid953", tween: [ "style", "${_transportCoord}", "top", '57.98%', { fromValue: '20.42%'}], position: 867, duration: 333 },
            { id: "eid984", tween: [ "style", "${_transportCoord}", "top", '60.7%', { fromValue: '57.92%'}], position: 1467, duration: 266 },
            { id: "eid995", tween: [ "style", "${_transportCoord}", "top", '7.92%', { fromValue: '60.69%'}], position: 1733, duration: 200 },
            { id: "eid1018", tween: [ "style", "${_transportCoord}", "top", '93.72%', { fromValue: '7.92%'}], position: 2133, duration: 334 },
            { id: "eid946", tween: [ "style", "${_securityCood}", "opacity", '1', { fromValue: '1'}], position: 600, duration: 0 },
            { id: "eid972", tween: [ "style", "${_securityCood}", "opacity", '1', { fromValue: '1'}], position: 1467, duration: 0 },
            { id: "eid1025", tween: [ "style", "${_securityCood}", "opacity", '0', { fromValue: '1'}], position: 2133, duration: 334 },
            { id: "eid942", tween: [ "style", "${_transportCoord}", "opacity", '1', { fromValue: '1'}], position: 600, duration: 0 },
            { id: "eid967", tween: [ "style", "${_transportCoord}", "opacity", '1', { fromValue: '1'}], position: 1467, duration: 0 },
            { id: "eid1019", tween: [ "style", "${_transportCoord}", "opacity", '0', { fromValue: '1'}], position: 2133, duration: 334 },
            { id: "eid943", tween: [ "style", "${_opCoord2}", "opacity", '1', { fromValue: '1'}], position: 600, duration: 0 },
            { id: "eid975", tween: [ "style", "${_opCoord2}", "opacity", '1', { fromValue: '1'}], position: 1467, duration: 0 },
            { id: "eid1022", tween: [ "style", "${_opCoord2}", "opacity", '0', { fromValue: '1'}], position: 2133, duration: 334 },
            { id: "eid950", tween: [ "style", "${_opCoord2}", "top", '20.42%', { fromValue: '-18.06%'}], position: 600, duration: 267 },
            { id: "eid957", tween: [ "style", "${_opCoord2}", "top", '57.92%', { fromValue: '20.42%'}], position: 867, duration: 333 },
            { id: "eid985", tween: [ "style", "${_opCoord2}", "top", '7.92%', { fromValue: '57.92%'}], position: 1467, duration: 266 },
            { id: "eid997", tween: [ "style", "${_opCoord2}", "top", '60.69%', { fromValue: '7.92%'}], position: 1733, duration: 200 },
            { id: "eid1002", tween: [ "style", "${_opCoord2}", "top", '60.69%', { fromValue: '60.69%'}], position: 1933, duration: 200 },
            { id: "eid1021", tween: [ "style", "${_opCoord2}", "top", '-22.17%', { fromValue: '60.69%'}], position: 2133, duration: 334 },
            { id: "eid949", tween: [ "style", "${_opCoord}", "top", '20.42%', { fromValue: '-18.06%'}], position: 600, duration: 267 },
            { id: "eid959", tween: [ "style", "${_opCoord}", "top", '57.92%', { fromValue: '20.42%'}], position: 867, duration: 333 },
            { id: "eid988", tween: [ "style", "${_opCoord}", "top", '60.69%', { fromValue: '57.92%'}], position: 1467, duration: 266 },
            { id: "eid993", tween: [ "style", "${_opCoord}", "top", '10.69%', { fromValue: '60.69%'}], position: 1733, duration: 200 },
            { id: "eid1003", tween: [ "style", "${_opCoord}", "top", '60.69%', { fromValue: '10.69%'}], position: 1933, duration: 200 },
            { id: "eid1027", tween: [ "style", "${_opCoord}", "top", '-22.22%', { fromValue: '60.69%'}], position: 2133, duration: 334 },
            { id: "eid934", tween: [ "style", "${_opCore}", "left", '44.92%', { fromValue: '44.92%'}], position: 600, duration: 0 },
            { id: "eid961", tween: [ "style", "${_opCore}", "left", '44.92%', { fromValue: '44.92%'}], position: 1200, duration: 0 },
            { id: "eid979", tween: [ "style", "${_opCore}", "left", '47.87%', { fromValue: '44.92%'}], position: 1467, duration: 266 },
            { id: "eid998", tween: [ "style", "${_opCore}", "left", '47.87%', { fromValue: '47.87%'}], position: 1933, duration: 0 },
            { id: "eid1012", tween: [ "style", "${_opCore}", "left", '47.87%', { fromValue: '47.87%'}], position: 2133, duration: 0 },
            { id: "eid947", tween: [ "style", "${_opCore}", "top", '20.42%', { fromValue: '-18.06%'}], position: 600, duration: 267 },
            { id: "eid962", tween: [ "style", "${_opCore}", "top", '20.42%', { fromValue: '20.42%'}], position: 1200, duration: 0 },
            { id: "eid980", tween: [ "style", "${_opCore}", "top", '29.44%', { fromValue: '20.42%'}], position: 1467, duration: 266 },
            { id: "eid999", tween: [ "style", "${_opCore}", "top", '29.44%', { fromValue: '29.44%'}], position: 1933, duration: 0 },
            { id: "eid1013", tween: [ "style", "${_opCore}", "top", '29.44%', { fromValue: '29.44%'}], position: 2133, duration: 0 },
            { id: "eid956", tween: [ "style", "${_opCoord2}", "left", '59.71%', { fromValue: '44.92%'}], position: 600, duration: 600 },
            { id: "eid986", tween: [ "style", "${_opCoord2}", "left", '67.26%', { fromValue: '59.69%'}], position: 1467, duration: 266 },
            { id: "eid996", tween: [ "style", "${_opCoord2}", "left", '26.25%', { fromValue: '67.27%'}], position: 1733, duration: 200 },
            { id: "eid1001", tween: [ "style", "${_opCoord2}", "left", '68.36%', { fromValue: '26.25%'}], position: 1933, duration: 200 },
            { id: "eid1020", tween: [ "style", "${_opCoord2}", "left", '15.78%', { fromValue: '68.36%'}], position: 2133, duration: 334 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-80833650");
