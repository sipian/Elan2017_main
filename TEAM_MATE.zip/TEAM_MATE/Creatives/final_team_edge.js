/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.5.0",
   minimumCompatibleVersion: "1.5.0",
   build: "1.5.0.217",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'creat_btn2',
            type:'image',
            rect:['0%','6.1%','11.7%','6.3%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"creat_btn.png",'0px','0px']
         },
         {
            id:'creatCore',
            type:'image',
            rect:['46.1%','-21.2%','10.2%','18.1%','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"creatCore.png",'0px','0px']
         },
         {
            id:'creatCood1',
            type:'image',
            rect:['46.1%','-20.6%','10.2%','18.1%','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"creatCood1.png",'0px','0px']
         },
         {
            id:'creatCood2',
            type:'image',
            rect:['46.1%','-21.2%','10.2%','18.1%','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"creatCood2.png",'0px','0px']
         },
         {
            id:'creatCood32',
            type:'image',
            rect:['46.1%','-21.2%','10.2%','18.1%','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"creatCood32.png",'0px','0px']
         },
         {
            id:'webCood12',
            type:'image',
            rect:['46.1%','-20.6%','10.2%','18.1%','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"webCood12.png",'0px','0px']
         },
         {
            id:'webCood22',
            type:'image',
            rect:['46.1%','-21.2%','10.2%','18.1%','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"webCood22.png",'0px','0px']
         },
         {
            id:'multiCood2',
            type:'image',
            rect:['46.1%','-21.2%','10.2%','18.1%','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"multiCood2.png",'0px','0px']
         },
         {
            id:'multiCood3',
            type:'image',
            rect:['46.1%','-21.2%','10.2%','18.1%','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"multiCood3.png",'0px','0px']
         },
         {
            id:'hospi_btn_1',
            type:'image',
            rect:['0%','12.8%','11.7%','6.3%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"hospi_btn_1.png",'0px','0px']
         },
         {
            id:'markt_btn',
            type:'image',
            rect:['0%','19.7%','11.7%','6.3%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"markt_btn.png",'0px','0px']
         },
         {
            id:'finan_btn',
            type:'image',
            rect:['0%','26%','11.7%','6.3%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"finan_btn.png",'0px','0px']
         },
         {
            id:'events_btn',
            type:'image',
            rect:['0%','32.2%','11.7%','6.3%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"events_btn.png",'0px','0px']
         },
         {
            id:'optrans_btn',
            type:'image',
            rect:['0%','37.4%','11.7%','7.2%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"optrans_btn.png",'0px','0px']
         },
         {
            id:'overall_btn',
            type:'image',
            rect:['0%','43.9%','11.7%','7.2%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"overall_btn.png",'0px','0px']
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_overall_btn}": [
            ["style", "top", '43.88%'],
            ["style", "height", '7.22%'],
            ["style", "left", '0%'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '11.72%']
         ],
         "${_hospi_btn_1}": [
            ["style", "top", '12.78%'],
            ["style", "height", '6.25%'],
            ["style", "left", '0%'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '11.72%']
         ],
         "${_optrans_btn}": [
            ["style", "top", '37.36%'],
            ["style", "height", '7.22%'],
            ["style", "left", '0%'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '11.72%']
         ],
         "${_multiCood2}": [
            ["style", "top", '-21.25%'],
            ["style", "opacity", '1'],
            ["style", "left", '46.09%']
         ],
         "${_creatCood2}": [
            ["style", "top", '-21.25%'],
            ["style", "opacity", '1'],
            ["style", "left", '46.09%']
         ],
         "${_creatCood1}": [
            ["style", "top", '-20.56%'],
            ["style", "opacity", '1'],
            ["style", "left", '46.09%']
         ],
         "${_finan_btn}": [
            ["style", "top", '25.97%'],
            ["style", "height", '6.25%'],
            ["style", "left", '0%'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '11.72%']
         ],
         "${_creatCood32}": [
            ["style", "top", '-21.25%'],
            ["style", "opacity", '1'],
            ["style", "left", '46.09%']
         ],
         "${_events_btn}": [
            ["style", "top", '32.22%'],
            ["style", "height", '6.25%'],
            ["style", "left", '0%'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '11.72%']
         ],
         "${_markt_btn}": [
            ["style", "top", '19.71%'],
            ["style", "height", '6.25%'],
            ["style", "left", '0%'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '11.72%']
         ],
         "${_creatCore}": [
            ["style", "top", '-21.25%'],
            ["style", "opacity", '1'],
            ["style", "left", '46.11%']
         ],
         "${_multiCood3}": [
            ["style", "top", '-21.25%'],
            ["style", "opacity", '1'],
            ["style", "left", '46.09%']
         ],
         "${_Stage}": [
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "min-width", '350px'],
            ["style", "overflow", 'hidden'],
            ["style", "height", '100%'],
            ["style", "width", '100%']
         ],
         "${_webCood12}": [
            ["style", "top", '-20.56%'],
            ["style", "opacity", '1'],
            ["style", "left", '46.09%']
         ],
         "${_creat_btn2}": [
            ["style", "top", '6.11%'],
            ["style", "height", '6.25%'],
            ["style", "left", '0%'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '11.72%']
         ],
         "${_webCood22}": [
            ["style", "top", '-21.25%'],
            ["style", "opacity", '1'],
            ["style", "left", '46.09%']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 3867,
         autoPlay: true,
         labels: {
            "in": 200,
            "shortIn": 600,
            "out": 3000
         },
         timeline: [
            { id: "eid873", tween: [ "style", "${_webCood22}", "opacity", '0', { fromValue: '1'}], position: 3000, duration: 867 },
            { id: "eid867", tween: [ "style", "${_multiCood3}", "opacity", '0', { fromValue: '1'}], position: 3000, duration: 867 },
            { id: "eid870", tween: [ "style", "${_creatCood1}", "opacity", '0', { fromValue: '1'}], position: 3000, duration: 867 },
            { id: "eid871", tween: [ "style", "${_creatCood32}", "opacity", '0', { fromValue: '1'}], position: 3000, duration: 867 },
            { id: "eid868", tween: [ "style", "${_multiCood2}", "opacity", '0', { fromValue: '1'}], position: 3000, duration: 867 },
            { id: "eid797", tween: [ "style", "${_webCood22}", "top", '14.58%', { fromValue: '-21.25%'}], position: 600, duration: 1067 },
            { id: "eid816", tween: [ "style", "${_webCood22}", "top", '42.64%', { fromValue: '14.58%'}], position: 1667, duration: 1000 },
            { id: "eid865", tween: [ "style", "${_webCood22}", "top", '37.92%', { fromValue: '42.64%'}], position: 3000, duration: 867 },
            { id: "eid792", tween: [ "style", "${_multiCood3}", "left", '46.09%', { fromValue: '46.09%'}], position: 600, duration: 0 },
            { id: "eid813", tween: [ "style", "${_multiCood3}", "left", '21.88%', { fromValue: '46.09%'}], position: 1667, duration: 1000 },
            { id: "eid852", tween: [ "style", "${_multiCood3}", "left", '-76%', { fromValue: '21.88%'}], position: 3000, duration: 867 },
            { id: "eid794", tween: [ "style", "${_multiCood3}", "top", '15.28%', { fromValue: '-21.25%'}], position: 600, duration: 1067 },
            { id: "eid812", tween: [ "style", "${_multiCood3}", "top", '43.06%', { fromValue: '15.28%'}], position: 1667, duration: 1000 },
            { id: "eid853", tween: [ "style", "${_multiCood3}", "top", '38.34%', { fromValue: '43.06%'}], position: 3000, duration: 867 },
            { id: "eid795", tween: [ "style", "${_creatCore}", "top", '14.58%', { fromValue: '-21.25%'}], position: 600, duration: 1067 },
            { id: "eid863", tween: [ "style", "${_creatCore}", "top", '9.86%', { fromValue: '14.58%'}], position: 3000, duration: 867 },
            { id: "eid796", tween: [ "style", "${_creatCood32}", "top", '14.58%', { fromValue: '-21.25%'}], position: 600, duration: 1067 },
            { id: "eid820", tween: [ "style", "${_creatCood32}", "top", '71.67%', { fromValue: '14.58%'}], position: 1667, duration: 1000 },
            { id: "eid861", tween: [ "style", "${_creatCood32}", "top", '66.95%', { fromValue: '71.67%'}], position: 3000, duration: 867 },
            { id: "eid777", tween: [ "style", "${_creatCore}", "left", '46.11%', { fromValue: '46.11%'}], position: 600, duration: 0 },
            { id: "eid805", tween: [ "style", "${_creatCore}", "left", '46.11%', { fromValue: '46.11%'}], position: 1667, duration: 0 },
            { id: "eid862", tween: [ "style", "${_creatCore}", "left", '-51.77%', { fromValue: '46.11%'}], position: 3000, duration: 867 },
            { id: "eid786", tween: [ "style", "${_webCood12}", "left", '46.09%', { fromValue: '46.09%'}], position: 600, duration: 0 },
            { id: "eid819", tween: [ "style", "${_webCood12}", "left", '5%', { fromValue: '46.09%'}], position: 1667, duration: 1000 },
            { id: "eid856", tween: [ "style", "${_webCood12}", "left", '-92.88%', { fromValue: '5%'}], position: 3000, duration: 867 },
            { id: "eid799", tween: [ "style", "${_multiCood2}", "top", '14.58%', { fromValue: '-21.25%'}], position: 600, duration: 1067 },
            { id: "eid814", tween: [ "style", "${_multiCood2}", "top", '43.06%', { fromValue: '14.58%'}], position: 1667, duration: 1000 },
            { id: "eid855", tween: [ "style", "${_multiCood2}", "top", '38.34%', { fromValue: '43.06%'}], position: 3000, duration: 867 },
            { id: "eid869", tween: [ "style", "${_webCood12}", "opacity", '0', { fromValue: '1'}], position: 3000, duration: 867 },
            { id: "eid866", tween: [ "style", "${_creatCood2}", "opacity", '0', { fromValue: '1'}], position: 3000, duration: 867 },
            { id: "eid798", tween: [ "style", "${_webCood12}", "top", '15.28%', { fromValue: '-20.56%'}], position: 600, duration: 1067 },
            { id: "eid818", tween: [ "style", "${_webCood12}", "top", '71.67%', { fromValue: '15.28%'}], position: 1667, duration: 1000 },
            { id: "eid857", tween: [ "style", "${_webCood12}", "top", '66.95%', { fromValue: '71.67%'}], position: 3000, duration: 867 },
            { id: "eid800", tween: [ "style", "${_creatCood1}", "top", '15.28%', { fromValue: '-20.56%'}], position: 600, duration: 1067 },
            { id: "eid825", tween: [ "style", "${_creatCood1}", "top", '71.67%', { fromValue: '15.28%'}], position: 1667, duration: 1000 },
            { id: "eid859", tween: [ "style", "${_creatCood1}", "top", '66.95%', { fromValue: '71.67%'}], position: 3000, duration: 867 },
            { id: "eid781", tween: [ "style", "${_creatCood2}", "left", '46.09%', { fromValue: '46.09%'}], position: 600, duration: 0 },
            { id: "eid823", tween: [ "style", "${_creatCood2}", "left", '60.14%', { fromValue: '46.09%'}], position: 1667, duration: 1000 },
            { id: "eid850", tween: [ "style", "${_creatCood2}", "left", '-37.74%', { fromValue: '60.14%'}], position: 3000, duration: 867 },
            { id: "eid872", tween: [ "style", "${_creatCore}", "opacity", '0', { fromValue: '1'}], position: 3000, duration: 867 },
            { id: "eid790", tween: [ "style", "${_multiCood2}", "left", '46.09%', { fromValue: '46.09%'}], position: 600, duration: 0 },
            { id: "eid815", tween: [ "style", "${_multiCood2}", "left", '46.33%', { fromValue: '46.09%'}], position: 1667, duration: 1000 },
            { id: "eid854", tween: [ "style", "${_multiCood2}", "left", '-51.55%', { fromValue: '46.33%'}], position: 3000, duration: 867 },
            { id: "eid788", tween: [ "style", "${_webCood22}", "left", '46.09%', { fromValue: '46.09%'}], position: 600, duration: 0 },
            { id: "eid817", tween: [ "style", "${_webCood22}", "left", '68.98%', { fromValue: '46.09%'}], position: 1667, duration: 1000 },
            { id: "eid864", tween: [ "style", "${_webCood22}", "left", '-28.9%', { fromValue: '68.98%'}], position: 3000, duration: 867 },
            { id: "eid801", tween: [ "style", "${_creatCood2}", "top", '14.58%', { fromValue: '-21.25%'}], position: 600, duration: 1067 },
            { id: "eid822", tween: [ "style", "${_creatCood2}", "top", '71.67%', { fromValue: '14.58%'}], position: 1667, duration: 1000 },
            { id: "eid851", tween: [ "style", "${_creatCood2}", "top", '66.95%', { fromValue: '71.67%'}], position: 3000, duration: 867 },
            { id: "eid779", tween: [ "style", "${_creatCood1}", "left", '46.09%', { fromValue: '46.09%'}], position: 600, duration: 0 },
            { id: "eid824", tween: [ "style", "${_creatCood1}", "left", '87.13%', { fromValue: '46.09%'}], position: 1667, duration: 1000 },
            { id: "eid858", tween: [ "style", "${_creatCood1}", "left", '-10.75%', { fromValue: '87.13%'}], position: 3000, duration: 867 },
            { id: "eid784", tween: [ "style", "${_creatCood32}", "left", '46.09%', { fromValue: '46.09%'}], position: 600, duration: 0 },
            { id: "eid821", tween: [ "style", "${_creatCood32}", "left", '32.03%', { fromValue: '46.09%'}], position: 1667, duration: 1000 },
            { id: "eid860", tween: [ "style", "${_creatCood32}", "left", '-65.85%', { fromValue: '32.03%'}], position: 3000, duration: 867 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-80833651");
