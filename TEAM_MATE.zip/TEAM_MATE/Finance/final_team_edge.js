/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.5.0",
   minimumCompatibleVersion: "1.5.0",
   build: "1.5.0.217",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'creat_btn2',
            type:'image',
            rect:['0%','6.1%','11.7%','6.3%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"creat_btn.png",'0px','0px']
         },
         {
            id:'hospi_btn_1',
            type:'image',
            rect:['0%','12.8%','11.7%','6.3%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"hospi_btn_1.png",'0px','0px']
         },
         {
            id:'markt_btn',
            type:'image',
            rect:['0%','19.7%','11.7%','6.3%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"markt_btn.png",'0px','0px']
         },
         {
            id:'finan_btn',
            type:'image',
            rect:['0%','26%','11.7%','6.3%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"finan_btn.png",'0px','0px']
         },
         {
            id:'events_btn',
            type:'image',
            rect:['0%','32.2%','11.7%','6.3%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"events_btn.png",'0px','0px']
         },
         {
            id:'optrans_btn',
            type:'image',
            rect:['0%','37.4%','11.7%','7.2%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"optrans_btn.png",'0px','0px']
         },
         {
            id:'overall_btn',
            type:'image',
            rect:['0%','43.9%','11.7%','7.2%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"overall_btn.png",'0px','0px']
         },
         {
            id:'asstinfra',
            type:'image',
            rect:['43.2%','-26.4%','13.6%','26.4%','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"asstinfra.jpg",'0px','0px']
         },
         {
            id:'financeCoord',
            type:'image',
            rect:['43.2%','-26.4%','10.2%','18.1%','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"financeCoord.png",'0px','0px']
         },
         {
            id:'financeCore',
            type:'image',
            rect:['43.2%','-26.4%','10.2%','18.1%','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"financeCore.png",'0px','0px']
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_overall_btn}": [
            ["style", "top", '43.88%'],
            ["style", "height", '7.22%'],
            ["style", "cursor", 'pointer'],
            ["style", "left", '0%'],
            ["style", "width", '11.72%']
         ],
         "${_finan_btn}": [
            ["style", "top", '25.97%'],
            ["style", "height", '6.25%'],
            ["style", "cursor", 'pointer'],
            ["style", "left", '0%'],
            ["style", "width", '11.72%']
         ],
         "${_markt_btn}": [
            ["style", "top", '19.71%'],
            ["style", "height", '6.25%'],
            ["style", "cursor", 'pointer'],
            ["style", "left", '0%'],
            ["style", "width", '11.72%']
         ],
         "${_asstinfra}": [
            ["style", "top", '-26.39%'],
            ["style", "opacity", '1'],
            ["style", "left", '43.2%']
         ],
         "${_financeCoord}": [
            ["style", "top", '-26.39%'],
            ["style", "opacity", '1'],
            ["style", "left", '43.2%']
         ],
         "${_events_btn}": [
            ["style", "top", '32.22%'],
            ["style", "height", '6.25%'],
            ["style", "cursor", 'pointer'],
            ["style", "left", '0%'],
            ["style", "width", '11.72%']
         ],
         "${_financeCore}": [
            ["style", "top", '-26.39%'],
            ["style", "opacity", '1'],
            ["style", "left", '43.2%']
         ],
         "${_Stage}": [
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "min-width", '350px'],
            ["style", "overflow", 'hidden'],
            ["style", "height", '100%'],
            ["style", "width", '100%']
         ],
         "${_hospi_btn_1}": [
            ["style", "top", '12.78%'],
            ["style", "height", '6.25%'],
            ["style", "cursor", 'pointer'],
            ["style", "left", '0%'],
            ["style", "width", '11.72%']
         ],
         "${_creat_btn2}": [
            ["style", "top", '6.11%'],
            ["style", "height", '6.25%'],
            ["style", "cursor", 'pointer'],
            ["style", "left", '0%'],
            ["style", "width", '11.72%']
         ],
         "${_optrans_btn}": [
            ["style", "top", '37.36%'],
            ["style", "height", '7.22%'],
            ["style", "cursor", 'pointer'],
            ["style", "left", '0%'],
            ["style", "width", '11.72%']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 2333,
         autoPlay: true,
         labels: {
            "in": 200,
            "shortIn": 600,
            "out": 1600
         },
         timeline: [
            { id: "eid918", tween: [ "style", "${_asstinfra}", "left", '43.2%', { fromValue: '43.2%'}], position: 600, duration: 0 },
            { id: "eid935", tween: [ "style", "${_asstinfra}", "left", '13.71%', { fromValue: '43.2%'}], position: 1000, duration: 267 },
            { id: "eid947", tween: [ "style", "${_asstinfra}", "left", '40.56%', { fromValue: '13.71%'}], position: 1600, duration: 267 },
            { id: "eid960", tween: [ "style", "${_asstinfra}", "left", '0.96%', { fromValue: '40.56%'}], position: 1867, duration: 466 },
            { id: "eid923", tween: [ "style", "${_financeCore}", "opacity", '1', { fromValue: '1'}], position: 600, duration: 0 },
            { id: "eid932", tween: [ "style", "${_financeCore}", "opacity", '1', { fromValue: '1'}], position: 1000, duration: 0 },
            { id: "eid959", tween: [ "style", "${_financeCore}", "opacity", '0', { fromValue: '1'}], position: 1600, duration: 733 },
            { id: "eid917", tween: [ "style", "${_financeCore}", "left", '43.2%', { fromValue: '43.2%'}], position: 600, duration: 0 },
            { id: "eid929", tween: [ "style", "${_financeCore}", "left", '43.2%', { fromValue: '43.2%'}], position: 1000, duration: 0 },
            { id: "eid939", tween: [ "style", "${_financeCore}", "left", '43.2%', { fromValue: '43.2%'}], position: 1267, duration: 0 },
            { id: "eid957", tween: [ "style", "${_financeCore}", "left", '70.15%', { fromValue: '43.2%'}], position: 1600, duration: 733 },
            { id: "eid924", tween: [ "style", "${_asstinfra}", "opacity", '1', { fromValue: '1'}], position: 600, duration: 0 },
            { id: "eid933", tween: [ "style", "${_asstinfra}", "opacity", '1', { fromValue: '1'}], position: 1000, duration: 0 },
            { id: "eid962", tween: [ "style", "${_asstinfra}", "opacity", '0', { fromValue: '1'}], position: 1600, duration: 733 },
            { id: "eid926", tween: [ "style", "${_asstinfra}", "top", '30.69%', { fromValue: '-26.39%'}], position: 600, duration: 400 },
            { id: "eid936", tween: [ "style", "${_asstinfra}", "top", '63.65%', { fromValue: '30.69%'}], position: 1000, duration: 267 },
            { id: "eid948", tween: [ "style", "${_asstinfra}", "top", '27.78%', { fromValue: '63.65%'}], position: 1600, duration: 267 },
            { id: "eid961", tween: [ "style", "${_asstinfra}", "top", '-35.46%', { fromValue: '27.78%'}], position: 1867, duration: 466 },
            { id: "eid927", tween: [ "style", "${_financeCoord}", "top", '30.69%', { fromValue: '-26.39%'}], position: 600, duration: 400 },
            { id: "eid938", tween: [ "style", "${_financeCoord}", "top", '64.86%', { fromValue: '30.69%'}], position: 1000, duration: 267 },
            { id: "eid953", tween: [ "style", "${_financeCoord}", "top", '30.69%', { fromValue: '64.86%'}], position: 1600, duration: 267 },
            { id: "eid955", tween: [ "style", "${_financeCoord}", "top", '106.54%', { fromValue: '30.69%'}], position: 1867, duration: 466 },
            { id: "eid928", tween: [ "style", "${_financeCore}", "top", '30.69%', { fromValue: '-26.39%'}], position: 600, duration: 400 },
            { id: "eid940", tween: [ "style", "${_financeCore}", "top", '30.69%', { fromValue: '30.69%'}], position: 1267, duration: 0 },
            { id: "eid958", tween: [ "style", "${_financeCore}", "top", '-22.96%', { fromValue: '30.69%'}], position: 1600, duration: 733 },
            { id: "eid919", tween: [ "style", "${_financeCoord}", "left", '43.2%', { fromValue: '43.2%'}], position: 600, duration: 0 },
            { id: "eid937", tween: [ "style", "${_financeCoord}", "left", '72.05%', { fromValue: '43.2%'}], position: 1000, duration: 267 },
            { id: "eid952", tween: [ "style", "${_financeCoord}", "left", '43.98%', { fromValue: '72.05%'}], position: 1600, duration: 267 },
            { id: "eid954", tween: [ "style", "${_financeCoord}", "left", '13.77%', { fromValue: '43.98%'}], position: 1867, duration: 466 },
            { id: "eid925", tween: [ "style", "${_financeCoord}", "opacity", '1', { fromValue: '1'}], position: 600, duration: 0 },
            { id: "eid934", tween: [ "style", "${_financeCoord}", "opacity", '1', { fromValue: '1'}], position: 1000, duration: 0 },
            { id: "eid956", tween: [ "style", "${_financeCoord}", "opacity", '0', { fromValue: '1'}], position: 1600, duration: 733 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-80833650");
