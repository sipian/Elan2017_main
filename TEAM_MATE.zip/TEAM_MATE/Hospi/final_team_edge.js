/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.5.0",
   minimumCompatibleVersion: "1.5.0",
   build: "1.5.0.217",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'creat_btn2',
            type:'image',
            rect:['0%','6.1%','11.7%','6.3%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"creat_btn.png",'0px','0px']
         },
         {
            id:'hospi_btn_1',
            type:'image',
            rect:['0%','12.8%','11.7%','6.3%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"hospi_btn_1.png",'0px','0px']
         },
         {
            id:'markt_btn',
            type:'image',
            rect:['0%','19.7%','11.7%','6.3%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"markt_btn.png",'0px','0px']
         },
         {
            id:'finan_btn',
            type:'image',
            rect:['0%','26%','11.7%','6.3%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"finan_btn.png",'0px','0px']
         },
         {
            id:'events_btn',
            type:'image',
            rect:['0%','32.2%','11.7%','6.3%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"events_btn.png",'0px','0px']
         },
         {
            id:'optrans_btn',
            type:'image',
            rect:['0%','37.4%','11.7%','7.2%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"optrans_btn.png",'0px','0px']
         },
         {
            id:'overall_btn',
            type:'image',
            rect:['0%','43.9%','11.7%','7.2%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"overall_btn.png",'0px','0px']
         },
         {
            id:'cpCoord1',
            type:'image',
            rect:['44.9%','-22.4%','10.2%','18.1%','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"cpCoord1.png",'0px','0px']
         },
         {
            id:'cpCoord2',
            type:'image',
            rect:['44.9%','-22.4%','10.2%','18.1%','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"cpCoord2.png",'0px','0px']
         },
         {
            id:'hospiCoord1',
            type:'image',
            rect:['44.9%','-22.4%','10.2%','18.1%','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"hospiCoord1.png",'0px','0px']
         },
         {
            id:'hospiCoord2',
            type:'image',
            rect:['44.9%','-22.4%','10.2%','18.1%','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"hospiCoord2.png",'0px','0px']
         },
         {
            id:'hospiCore',
            type:'image',
            rect:['44.9%','-22.4%','10.2%','18.1%','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"hospiCore.png",'0px','0px']
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_overall_btn}": [
            ["style", "top", '43.88%'],
            ["style", "height", '7.22%'],
            ["style", "cursor", 'pointer'],
            ["style", "left", '0%'],
            ["style", "width", '11.72%']
         ],
         "${_finan_btn}": [
            ["style", "top", '25.97%'],
            ["style", "height", '6.25%'],
            ["style", "cursor", 'pointer'],
            ["style", "left", '0%'],
            ["style", "width", '11.72%']
         ],
         "${_markt_btn}": [
            ["style", "top", '19.71%'],
            ["style", "height", '6.25%'],
            ["style", "cursor", 'pointer'],
            ["style", "left", '0%'],
            ["style", "width", '11.72%']
         ],
         "${_hospiCoord2}": [
            ["style", "top", '-22.43%'],
            ["style", "opacity", '1'],
            ["style", "left", '44.92%']
         ],
         "${_optrans_btn}": [
            ["style", "top", '37.36%'],
            ["style", "height", '7.22%'],
            ["style", "cursor", 'pointer'],
            ["style", "left", '0%'],
            ["style", "width", '11.72%']
         ],
         "${_events_btn}": [
            ["style", "top", '32.22%'],
            ["style", "height", '6.25%'],
            ["style", "cursor", 'pointer'],
            ["style", "left", '0%'],
            ["style", "width", '11.72%']
         ],
         "${_cpCoord2}": [
            ["style", "top", '-22.43%'],
            ["style", "opacity", '1'],
            ["style", "left", '44.92%']
         ],
         "${_cpCoord1}": [
            ["style", "top", '-22.43%'],
            ["style", "opacity", '1'],
            ["style", "left", '44.92%']
         ],
         "${_hospiCore}": [
            ["style", "top", '-22.43%'],
            ["style", "opacity", '1'],
            ["style", "left", '44.92%']
         ],
         "${_Stage}": [
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "min-width", '350px'],
            ["style", "overflow", 'hidden'],
            ["style", "height", '100%'],
            ["style", "width", '100%']
         ],
         "${_hospi_btn_1}": [
            ["style", "top", '12.78%'],
            ["style", "height", '6.25%'],
            ["style", "cursor", 'pointer'],
            ["style", "left", '0%'],
            ["style", "width", '11.72%']
         ],
         "${_creat_btn2}": [
            ["style", "top", '6.11%'],
            ["style", "height", '6.25%'],
            ["style", "cursor", 'pointer'],
            ["style", "left", '0%'],
            ["style", "width", '11.72%']
         ],
         "${_hospiCoord1}": [
            ["style", "top", '-22.43%'],
            ["style", "opacity", '1'],
            ["style", "left", '44.92%']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 3007,
         autoPlay: true,
         labels: {
            "in": 200,
            "shortIn": 600,
            "out": 2200
         },
         timeline: [
            { id: "eid840", tween: [ "style", "${_hospiCoord2}", "opacity", '1', { fromValue: '1'}], position: 0, duration: 0 },
            { id: "eid869", tween: [ "style", "${_hospiCoord2}", "opacity", '1', { fromValue: '1'}], position: 1933, duration: 0 },
            { id: "eid912", tween: [ "style", "${_hospiCoord2}", "opacity", '0', { fromValue: '1'}], position: 2200, duration: 800 },
            { id: "eid835", tween: [ "style", "${_hospiCoord2}", "top", '-22.43%', { fromValue: '-22.43%'}], position: 0, duration: 0 },
            { id: "eid861", tween: [ "style", "${_hospiCoord2}", "top", '15.28%', { fromValue: '-22.5%'}], position: 600, duration: 667 },
            { id: "eid867", tween: [ "style", "${_hospiCoord2}", "top", '56.81%', { fromValue: '15.28%'}], position: 1267, duration: 666 },
            { id: "eid903", tween: [ "style", "${_hospiCoord2}", "top", '64.31%', { fromValue: '56.81%'}], position: 2200, duration: 800 },
            { id: "eid829", tween: [ "style", "${_hospiCoord1}", "left", '44.92%', { fromValue: '44.92%'}], position: 0, duration: 0 },
            { id: "eid844", tween: [ "style", "${_hospiCoord1}", "left", '44.92%', { fromValue: '44.92%'}], position: 600, duration: 0 },
            { id: "eid873", tween: [ "style", "${_hospiCoord1}", "left", '32.42%', { fromValue: '44.92%'}], position: 1267, duration: 666 },
            { id: "eid908", tween: [ "style", "${_hospiCoord1}", "left", '141.12%', { fromValue: '32.42%'}], position: 2200, duration: 800 },
            { id: "eid827", tween: [ "style", "${_cpCoord1}", "left", '44.92%', { fromValue: '44.92%'}], position: 0, duration: 0 },
            { id: "eid842", tween: [ "style", "${_cpCoord1}", "left", '44.92%', { fromValue: '44.92%'}], position: 600, duration: 0 },
            { id: "eid882", tween: [ "style", "${_cpCoord1}", "left", '84.96%', { fromValue: '44.92%'}], position: 1267, duration: 666 },
            { id: "eid910", tween: [ "style", "${_cpCoord1}", "left", '193.7%', { fromValue: '85%'}], position: 2200, duration: 800 },
            { id: "eid832", tween: [ "style", "${_cpCoord1}", "top", '-22.43%', { fromValue: '-22.43%'}], position: 0, duration: 0 },
            { id: "eid865", tween: [ "style", "${_cpCoord1}", "top", '15.28%', { fromValue: '-22.5%'}], position: 600, duration: 667 },
            { id: "eid883", tween: [ "style", "${_cpCoord1}", "top", '56.81%', { fromValue: '15.28%'}], position: 1267, duration: 666 },
            { id: "eid911", tween: [ "style", "${_cpCoord1}", "top", '64.31%', { fromValue: '56.81%'}], position: 2200, duration: 800 },
            { id: "eid839", tween: [ "style", "${_hospiCoord1}", "opacity", '1', { fromValue: '1'}], position: 0, duration: 0 },
            { id: "eid871", tween: [ "style", "${_hospiCoord1}", "opacity", '1', { fromValue: '1'}], position: 1267, duration: 0 },
            { id: "eid874", tween: [ "style", "${_hospiCoord1}", "opacity", '1', { fromValue: '1'}], position: 1933, duration: 0 },
            { id: "eid915", tween: [ "style", "${_hospiCoord1}", "opacity", '0', { fromValue: '1'}], position: 2200, duration: 800 },
            { id: "eid833", tween: [ "style", "${_cpCoord2}", "top", '-22.43%', { fromValue: '-22.43%'}], position: 0, duration: 0 },
            { id: "eid863", tween: [ "style", "${_cpCoord2}", "top", '15.28%', { fromValue: '-22.5%'}], position: 600, duration: 667 },
            { id: "eid877", tween: [ "style", "${_cpCoord2}", "top", '56.81%', { fromValue: '15.28%'}], position: 1267, duration: 666 },
            { id: "eid907", tween: [ "style", "${_cpCoord2}", "top", '64.31%', { fromValue: '56.81%'}], position: 2200, duration: 800 },
            { id: "eid826", tween: [ "style", "${_hospiCore}", "left", '44.92%', { fromValue: '44.92%'}], position: 0, duration: 0 },
            { id: "eid841", tween: [ "style", "${_hospiCore}", "left", '44.92%', { fromValue: '44.92%'}], position: 600, duration: 0 },
            { id: "eid884", tween: [ "style", "${_hospiCore}", "left", '44.92%', { fromValue: '44.92%'}], position: 1933, duration: 0 },
            { id: "eid904", tween: [ "style", "${_hospiCore}", "left", '153.62%', { fromValue: '44.92%'}], position: 2200, duration: 800 },
            { id: "eid831", tween: [ "style", "${_hospiCore}", "top", '-22.43%', { fromValue: '-22.43%'}], position: 0, duration: 0 },
            { id: "eid862", tween: [ "style", "${_hospiCore}", "top", '15.28%', { fromValue: '-22.5%'}], position: 600, duration: 667 },
            { id: "eid885", tween: [ "style", "${_hospiCore}", "top", '15.28%', { fromValue: '15.28%'}], position: 1933, duration: 0 },
            { id: "eid905", tween: [ "style", "${_hospiCore}", "top", '22.78%', { fromValue: '15.28%'}], position: 2200, duration: 800 },
            { id: "eid828", tween: [ "style", "${_cpCoord2}", "left", '44.92%', { fromValue: '44.92%'}], position: 0, duration: 0 },
            { id: "eid843", tween: [ "style", "${_cpCoord2}", "left", '44.92%', { fromValue: '44.92%'}], position: 600, duration: 0 },
            { id: "eid878", tween: [ "style", "${_cpCoord2}", "left", '59.61%', { fromValue: '44.92%'}], position: 1267, duration: 666 },
            { id: "eid906", tween: [ "style", "${_cpCoord2}", "left", '168.31%', { fromValue: '59.61%'}], position: 2200, duration: 800 },
            { id: "eid838", tween: [ "style", "${_cpCoord2}", "opacity", '1', { fromValue: '1'}], position: 0, duration: 0 },
            { id: "eid876", tween: [ "style", "${_cpCoord2}", "opacity", '1', { fromValue: '1'}], position: 1267, duration: 0 },
            { id: "eid879", tween: [ "style", "${_cpCoord2}", "opacity", '1', { fromValue: '1'}], position: 1933, duration: 0 },
            { id: "eid914", tween: [ "style", "${_cpCoord2}", "opacity", '0', { fromValue: '1'}], position: 2200, duration: 800 },
            { id: "eid836", tween: [ "style", "${_hospiCore}", "opacity", '1', { fromValue: '1'}], position: 0, duration: 0 },
            { id: "eid886", tween: [ "style", "${_hospiCore}", "opacity", '1', { fromValue: '1'}], position: 1933, duration: 0 },
            { id: "eid913", tween: [ "style", "${_hospiCore}", "opacity", '0', { fromValue: '1'}], position: 2200, duration: 800 },
            { id: "eid834", tween: [ "style", "${_hospiCoord1}", "top", '-22.43%', { fromValue: '-22.43%'}], position: 0, duration: 0 },
            { id: "eid864", tween: [ "style", "${_hospiCoord1}", "top", '15.28%', { fromValue: '-22.5%'}], position: 600, duration: 667 },
            { id: "eid872", tween: [ "style", "${_hospiCoord1}", "top", '56.81%', { fromValue: '15.28%'}], position: 1267, duration: 666 },
            { id: "eid909", tween: [ "style", "${_hospiCoord1}", "top", '64.31%', { fromValue: '56.81%'}], position: 2200, duration: 800 },
            { id: "eid837", tween: [ "style", "${_cpCoord1}", "opacity", '1', { fromValue: '1'}], position: 0, duration: 0 },
            { id: "eid881", tween: [ "style", "${_cpCoord1}", "opacity", '1', { fromValue: '1'}], position: 1267, duration: 0 },
            { id: "eid916", tween: [ "style", "${_cpCoord1}", "opacity", '0', { fromValue: '1'}], position: 2200, duration: 800 },
            { id: "eid830", tween: [ "style", "${_hospiCoord2}", "left", '44.92%', { fromValue: '44.92%'}], position: 0, duration: 0 },
            { id: "eid845", tween: [ "style", "${_hospiCoord2}", "left", '44.92%', { fromValue: '44.92%'}], position: 600, duration: 0 },
            { id: "eid868", tween: [ "style", "${_hospiCoord2}", "left", '6.64%', { fromValue: '44.92%'}], position: 1267, duration: 666 },
            { id: "eid902", tween: [ "style", "${_hospiCoord2}", "left", '115.34%', { fromValue: '6.64%'}], position: 2200, duration: 800 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-80833650");
