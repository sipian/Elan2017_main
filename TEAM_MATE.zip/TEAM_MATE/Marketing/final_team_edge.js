/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.5.0",
   minimumCompatibleVersion: "1.5.0",
   build: "1.5.0.217",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'creat_btn2',
            type:'image',
            rect:['0%','6.1%','11.7%','6.3%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"creat_btn.png",'0px','0px']
         },
         {
            id:'hospi_btn_1',
            type:'image',
            rect:['0%','12.8%','11.7%','6.3%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"hospi_btn_1.png",'0px','0px']
         },
         {
            id:'markt_btn',
            type:'image',
            rect:['0%','19.7%','11.7%','6.3%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"markt_btn.png",'0px','0px']
         },
         {
            id:'finan_btn',
            type:'image',
            rect:['0%','26%','11.7%','6.3%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"finan_btn.png",'0px','0px']
         },
         {
            id:'events_btn',
            type:'image',
            rect:['0%','32.2%','11.7%','6.3%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"events_btn.png",'0px','0px']
         },
         {
            id:'optrans_btn',
            type:'image',
            rect:['0%','37.4%','11.7%','7.2%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"optrans_btn.png",'0px','0px']
         },
         {
            id:'overall_btn',
            type:'image',
            rect:['0%','43.9%','11.7%','7.2%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"overall_btn.png",'0px','0px']
         },
         {
            id:'marketCoord1',
            type:'image',
            rect:['40.2%','-19.3%','10.2%','18.1%','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"marketCoord1.png",'0px','0px']
         },
         {
            id:'marketCoord2',
            type:'image',
            rect:['40.2%','-19.3%','10.2%','18.1%','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"marketCoord2.png",'0px','0px']
         },
         {
            id:'marketCoord3',
            type:'image',
            rect:['40.2%','-19.3%','10.2%','18.1%','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"marketCoord3.png",'0px','0px']
         },
         {
            id:'marketCoord4',
            type:'image',
            rect:['40.2%','-19.3%','10.2%','18.1%','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"marketCoord4.png",'0px','0px']
         },
         {
            id:'marketCore',
            type:'image',
            rect:['40.2%','-19.3%','10.2%','18.1%','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"marketCore.png",'0px','0px']
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_overall_btn}": [
            ["style", "top", '43.88%'],
            ["style", "height", '7.22%'],
            ["style", "cursor", 'pointer'],
            ["style", "left", '0%'],
            ["style", "width", '11.72%']
         ],
         "${_finan_btn}": [
            ["style", "top", '25.97%'],
            ["style", "height", '6.25%'],
            ["style", "cursor", 'pointer'],
            ["style", "left", '0%'],
            ["style", "width", '11.72%']
         ],
         "${_markt_btn}": [
            ["style", "top", '19.71%'],
            ["style", "height", '6.25%'],
            ["style", "cursor", 'pointer'],
            ["style", "left", '0%'],
            ["style", "width", '11.72%']
         ],
         "${_marketCoord4}": [
            ["style", "top", '-19.32%'],
            ["style", "opacity", '1'],
            ["style", "left", '40.19%']
         ],
         "${_optrans_btn}": [
            ["style", "top", '37.36%'],
            ["style", "height", '7.22%'],
            ["style", "cursor", 'pointer'],
            ["style", "left", '0%'],
            ["style", "width", '11.72%']
         ],
         "${_marketCoord1}": [
            ["style", "top", '-19.32%'],
            ["style", "opacity", '1'],
            ["style", "left", '40.19%']
         ],
         "${_marketCore}": [
            ["style", "top", '-19.32%'],
            ["style", "opacity", '1'],
            ["style", "left", '40.19%']
         ],
         "${_events_btn}": [
            ["style", "top", '32.22%'],
            ["style", "height", '6.25%'],
            ["style", "cursor", 'pointer'],
            ["style", "left", '0%'],
            ["style", "width", '11.72%']
         ],
         "${_marketCoord2}": [
            ["style", "top", '-19.32%'],
            ["style", "opacity", '1'],
            ["style", "left", '40.19%']
         ],
         "${_Stage}": [
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "min-width", '350px'],
            ["style", "overflow", 'hidden'],
            ["style", "height", '100%'],
            ["style", "width", '100%']
         ],
         "${_marketCoord3}": [
            ["style", "top", '-19.32%'],
            ["style", "opacity", '1'],
            ["style", "left", '40.19%']
         ],
         "${_creat_btn2}": [
            ["style", "top", '6.11%'],
            ["style", "height", '6.25%'],
            ["style", "cursor", 'pointer'],
            ["style", "left", '0%'],
            ["style", "width", '11.72%']
         ],
         "${_hospi_btn_1}": [
            ["style", "top", '12.78%'],
            ["style", "height", '6.25%'],
            ["style", "cursor", 'pointer'],
            ["style", "left", '0%'],
            ["style", "width", '11.72%']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 2733,
         autoPlay: true,
         labels: {
            "in": 200,
            "shortIn": 600,
            "out": 1533
         },
         timeline: [
            { id: "eid937", tween: [ "style", "${_marketCore}", "top", '21.33%', { fromValue: '-19.32%'}], position: 600, duration: 400 },
            { id: "eid956", tween: [ "style", "${_marketCore}", "top", '21.33%', { fromValue: '21.33%'}], position: 1267, duration: 0 },
            { id: "eid981", tween: [ "style", "${_marketCore}", "top", '38.47%', { fromValue: '21.33%'}], position: 1533, duration: 200 },
            { id: "eid1052", tween: [ "style", "${_marketCore}", "top", '38.47%', { fromValue: '38.47%'}], position: 1733, duration: 0 },
            { id: "eid1065", tween: [ "style", "${_marketCore}", "top", '38.47%', { fromValue: '38.47%'}], position: 2000, duration: 0 },
            { id: "eid1066", tween: [ "style", "${_marketCore}", "top", '37.36%', { fromValue: '38.47%'}], position: 2200, duration: 200 },
            { id: "eid1070", tween: [ "style", "${_marketCore}", "top", '38.47%', { fromValue: '37.36%'}], position: 2400, duration: 67 },
            { id: "eid1073", tween: [ "style", "${_marketCore}", "top", '38.47%', { fromValue: '38.47%'}], position: 2467, duration: 0 },
            { id: "eid1076", tween: [ "style", "${_marketCore}", "top", '38.47%', { fromValue: '38.47%'}], position: 2533, duration: 0 },
            { id: "eid1078", tween: [ "style", "${_marketCore}", "top", '38.47%', { fromValue: '38.47%'}], position: 2600, duration: 0 },
            { id: "eid1082", tween: [ "style", "${_marketCore}", "top", '-18.06%', { fromValue: '38.47%'}], position: 2667, duration: 66 },
            { id: "eid927", tween: [ "style", "${_marketCore}", "opacity", '1', { fromValue: '1'}], position: 600, duration: 0 },
            { id: "eid942", tween: [ "style", "${_marketCore}", "opacity", '1', { fromValue: '1'}], position: 1000, duration: 0 },
            { id: "eid957", tween: [ "style", "${_marketCore}", "opacity", '1', { fromValue: '1'}], position: 1267, duration: 0 },
            { id: "eid1054", tween: [ "style", "${_marketCore}", "opacity", '1', { fromValue: '1'}], position: 1533, duration: 0 },
            { id: "eid1061", tween: [ "style", "${_marketCore}", "opacity", '1', { fromValue: '1'}], position: 1733, duration: 0 },
            { id: "eid1062", tween: [ "style", "${_marketCore}", "opacity", '1', { fromValue: '1'}], position: 2000, duration: 0 },
            { id: "eid1063", tween: [ "style", "${_marketCore}", "opacity", '1', { fromValue: '1'}], position: 2200, duration: 0 },
            { id: "eid1068", tween: [ "style", "${_marketCore}", "opacity", '1', { fromValue: '1'}], position: 2400, duration: 0 },
            { id: "eid1071", tween: [ "style", "${_marketCore}", "opacity", '1', { fromValue: '1'}], position: 2467, duration: 0 },
            { id: "eid1074", tween: [ "style", "${_marketCore}", "opacity", '1', { fromValue: '1'}], position: 2533, duration: 0 },
            { id: "eid1077", tween: [ "style", "${_marketCore}", "opacity", '1', { fromValue: '1'}], position: 2600, duration: 0 },
            { id: "eid1080", tween: [ "style", "${_marketCore}", "opacity", '0', { fromValue: '1'}], position: 2667, duration: 66 },
            { id: "eid935", tween: [ "style", "${_marketCoord1}", "top", '21.33%', { fromValue: '-19.32%'}], position: 600, duration: 400 },
            { id: "eid954", tween: [ "style", "${_marketCoord1}", "top", '58.19%', { fromValue: '21.33%'}], position: 1000, duration: 267 },
            { id: "eid985", tween: [ "style", "${_marketCoord1}", "top", '38.47%', { fromValue: '58.19%'}], position: 1533, duration: 200 },
            { id: "eid989", tween: [ "style", "${_marketCoord1}", "top", '24.03%', { fromValue: '38.47%'}], position: 1733, duration: 267 },
            { id: "eid997", tween: [ "style", "${_marketCoord1}", "top", '10.97%', { fromValue: '24.03%'}], position: 2000, duration: 200 },
            { id: "eid1005", tween: [ "style", "${_marketCoord1}", "top", '3.33%', { fromValue: '10.97%'}], position: 2200, duration: 200 },
            { id: "eid1013", tween: [ "style", "${_marketCoord1}", "top", '1.94%', { fromValue: '3.33%'}], position: 2400, duration: 67 },
            { id: "eid1021", tween: [ "style", "${_marketCoord1}", "top", '11.6%', { fromValue: '1.94%'}], position: 2467, duration: 66 },
            { id: "eid1029", tween: [ "style", "${_marketCoord1}", "top", '18.14%', { fromValue: '11.6%'}], position: 2533, duration: 67 },
            { id: "eid1037", tween: [ "style", "${_marketCoord1}", "top", '37.36%', { fromValue: '18.14%'}], position: 2600, duration: 67 },
            { id: "eid1058", tween: [ "style", "${_marketCoord1}", "top", '-14.3%', { fromValue: '37.36%'}], position: 2667, duration: 66 },
            { id: "eid939", tween: [ "style", "${_marketCoord4}", "top", '21.33%', { fromValue: '-19.32%'}], position: 600, duration: 400 },
            { id: "eid948", tween: [ "style", "${_marketCoord4}", "top", '58.19%', { fromValue: '21.33%'}], position: 1000, duration: 267 },
            { id: "eid979", tween: [ "style", "${_marketCoord4}", "top", '38.47%', { fromValue: '58.19%'}], position: 1533, duration: 200 },
            { id: "eid993", tween: [ "style", "${_marketCoord4}", "top", '53.24%', { fromValue: '38.47%'}], position: 1733, duration: 267 },
            { id: "eid1001", tween: [ "style", "${_marketCoord4}", "top", '63.04%', { fromValue: '53.24%'}], position: 2000, duration: 200 },
            { id: "eid1009", tween: [ "style", "${_marketCoord4}", "top", '72.25%', { fromValue: '63.04%'}], position: 2200, duration: 200 },
            { id: "eid1017", tween: [ "style", "${_marketCoord4}", "top", '74.58%', { fromValue: '72.25%'}], position: 2400, duration: 67 },
            { id: "eid1025", tween: [ "style", "${_marketCoord4}", "top", '65.27%', { fromValue: '74.58%'}], position: 2467, duration: 66 },
            { id: "eid1033", tween: [ "style", "${_marketCoord4}", "top", '54.61%', { fromValue: '65.27%'}], position: 2533, duration: 67 },
            { id: "eid1044", tween: [ "style", "${_marketCoord4}", "top", '39.31%', { fromValue: '54.61%'}], position: 2600, duration: 67 },
            { id: "eid1046", tween: [ "style", "${_marketCoord4}", "top", '-17.4%', { fromValue: '39.31%'}], position: 2667, duration: 66 },
            { id: "eid934", tween: [ "style", "${_marketCoord1}", "left", '44.92%', { fromValue: '40.19%'}], position: 600, duration: 400 },
            { id: "eid953", tween: [ "style", "${_marketCoord1}", "left", '84.64%', { fromValue: '44.92%'}], position: 1000, duration: 267 },
            { id: "eid984", tween: [ "style", "${_marketCoord1}", "left", '63.28%', { fromValue: '84.64%'}], position: 1533, duration: 200 },
            { id: "eid988", tween: [ "style", "${_marketCoord1}", "left", '61.8%', { fromValue: '63.28%'}], position: 1733, duration: 267 },
            { id: "eid996", tween: [ "style", "${_marketCoord1}", "left", '55.9%', { fromValue: '61.8%'}], position: 2000, duration: 200 },
            { id: "eid1004", tween: [ "style", "${_marketCoord1}", "left", '48.05%', { fromValue: '55.9%'}], position: 2200, duration: 200 },
            { id: "eid1012", tween: [ "style", "${_marketCoord1}", "left", '42.97%', { fromValue: '48.05%'}], position: 2400, duration: 67 },
            { id: "eid1020", tween: [ "style", "${_marketCoord1}", "left", '29.46%', { fromValue: '42.97%'}], position: 2467, duration: 66 },
            { id: "eid1028", tween: [ "style", "${_marketCoord1}", "left", '26.11%', { fromValue: '29.46%'}], position: 2533, duration: 67 },
            { id: "eid1036", tween: [ "style", "${_marketCoord1}", "left", '22.65%', { fromValue: '26.11%'}], position: 2600, duration: 67 },
            { id: "eid1059", tween: [ "style", "${_marketCoord1}", "left", '21.23%', { fromValue: '22.65%'}], position: 2667, duration: 66 },
            { id: "eid931", tween: [ "style", "${_marketCoord4}", "opacity", '1', { fromValue: '1'}], position: 600, duration: 0 },
            { id: "eid946", tween: [ "style", "${_marketCoord4}", "opacity", '1', { fromValue: '1'}], position: 1000, duration: 0 },
            { id: "eid966", tween: [ "style", "${_marketCoord4}", "opacity", '1', { fromValue: '1'}], position: 1533, duration: 0 },
            { id: "eid1048", tween: [ "style", "${_marketCoord4}", "opacity", '0', { fromValue: '1'}], position: 2667, duration: 66 },
            { id: "eid930", tween: [ "style", "${_marketCoord3}", "opacity", '1', { fromValue: '1'}], position: 600, duration: 0 },
            { id: "eid945", tween: [ "style", "${_marketCoord3}", "opacity", '1', { fromValue: '1'}], position: 1000, duration: 0 },
            { id: "eid969", tween: [ "style", "${_marketCoord3}", "opacity", '1', { fromValue: '1'}], position: 1533, duration: 0 },
            { id: "eid1051", tween: [ "style", "${_marketCoord3}", "opacity", '0', { fromValue: '1'}], position: 2667, duration: 66 },
            { id: "eid929", tween: [ "style", "${_marketCoord2}", "opacity", '1', { fromValue: '1'}], position: 600, duration: 0 },
            { id: "eid944", tween: [ "style", "${_marketCoord2}", "opacity", '1', { fromValue: '1'}], position: 1000, duration: 0 },
            { id: "eid972", tween: [ "style", "${_marketCoord2}", "opacity", '1', { fromValue: '1'}], position: 1533, duration: 0 },
            { id: "eid1057", tween: [ "style", "${_marketCoord2}", "opacity", '0', { fromValue: '1'}], position: 2667, duration: 66 },
            { id: "eid936", tween: [ "style", "${_marketCore}", "left", '44.92%', { fromValue: '40.19%'}], position: 600, duration: 400 },
            { id: "eid955", tween: [ "style", "${_marketCore}", "left", '44.92%', { fromValue: '44.92%'}], position: 1267, duration: 0 },
            { id: "eid980", tween: [ "style", "${_marketCore}", "left", '42.97%', { fromValue: '44.92%'}], position: 1533, duration: 200 },
            { id: "eid1053", tween: [ "style", "${_marketCore}", "left", '43.28%', { fromValue: '42.97%'}], position: 1733, duration: 267 },
            { id: "eid1064", tween: [ "style", "${_marketCore}", "left", '42.99%', { fromValue: '43.28%'}], position: 2000, duration: 200 },
            { id: "eid1067", tween: [ "style", "${_marketCore}", "left", '42.97%', { fromValue: '42.99%'}], position: 2200, duration: 200 },
            { id: "eid1069", tween: [ "style", "${_marketCore}", "left", '42.42%', { fromValue: '42.97%'}], position: 2400, duration: 67 },
            { id: "eid1072", tween: [ "style", "${_marketCore}", "left", '42.95%', { fromValue: '42.42%'}], position: 2467, duration: 66 },
            { id: "eid1075", tween: [ "style", "${_marketCore}", "left", '43.27%', { fromValue: '42.95%'}], position: 2533, duration: 67 },
            { id: "eid1079", tween: [ "style", "${_marketCore}", "left", '42.55%', { fromValue: '43.27%'}], position: 2600, duration: 67 },
            { id: "eid1081", tween: [ "style", "${_marketCore}", "left", '42.46%', { fromValue: '42.55%'}], position: 2667, duration: 66 },
            { id: "eid933", tween: [ "style", "${_marketCoord3}", "top", '21.33%', { fromValue: '-19.32%'}], position: 600, duration: 400 },
            { id: "eid950", tween: [ "style", "${_marketCoord3}", "top", '58.19%', { fromValue: '21.33%'}], position: 1000, duration: 267 },
            { id: "eid976", tween: [ "style", "${_marketCoord3}", "top", '38.47%', { fromValue: '58.19%'}], position: 1533, duration: 200 },
            { id: "eid991", tween: [ "style", "${_marketCoord3}", "top", '45.87%', { fromValue: '38.47%'}], position: 1733, duration: 267 },
            { id: "eid999", tween: [ "style", "${_marketCoord3}", "top", '51.11%', { fromValue: '45.87%'}], position: 2000, duration: 200 },
            { id: "eid1007", tween: [ "style", "${_marketCoord3}", "top", '55.58%', { fromValue: '51.11%'}], position: 2200, duration: 200 },
            { id: "eid1015", tween: [ "style", "${_marketCoord3}", "top", '56.53%', { fromValue: '55.58%'}], position: 2400, duration: 67 },
            { id: "eid1023", tween: [ "style", "${_marketCoord3}", "top", '52.32%', { fromValue: '56.53%'}], position: 2467, duration: 66 },
            { id: "eid1031", tween: [ "style", "${_marketCoord3}", "top", '46.39%', { fromValue: '52.32%'}], position: 2533, duration: 67 },
            { id: "eid1040", tween: [ "style", "${_marketCoord3}", "top", '39.27%', { fromValue: '46.39%'}], position: 2600, duration: 67 },
            { id: "eid1050", tween: [ "style", "${_marketCoord3}", "top", '101.45%', { fromValue: '39.27%'}], position: 2667, duration: 66 },
            { id: "eid940", tween: [ "style", "${_marketCoord2}", "left", '44.92%', { fromValue: '40.19%'}], position: 600, duration: 400 },
            { id: "eid951", tween: [ "style", "${_marketCoord2}", "left", '59.23%', { fromValue: '44.92%'}], position: 1000, duration: 267 },
            { id: "eid982", tween: [ "style", "${_marketCoord2}", "left", '53.12%', { fromValue: '59.23%'}], position: 1533, duration: 200 },
            { id: "eid986", tween: [ "style", "${_marketCoord2}", "left", '52.68%', { fromValue: '53.12%'}], position: 1733, duration: 267 },
            { id: "eid994", tween: [ "style", "${_marketCoord2}", "left", '49.5%', { fromValue: '52.68%'}], position: 2000, duration: 200 },
            { id: "eid1002", tween: [ "style", "${_marketCoord2}", "left", '44.92%', { fromValue: '49.5%'}], position: 2200, duration: 200 },
            { id: "eid1010", tween: [ "style", "${_marketCoord2}", "left", '42.97%', { fromValue: '44.92%'}], position: 2400, duration: 67 },
            { id: "eid1018", tween: [ "style", "${_marketCoord2}", "left", '37.34%', { fromValue: '42.97%'}], position: 2467, duration: 66 },
            { id: "eid1026", tween: [ "style", "${_marketCoord2}", "left", '34.53%', { fromValue: '37.34%'}], position: 2533, duration: 67 },
            { id: "eid1034", tween: [ "style", "${_marketCoord2}", "left", '32.81%', { fromValue: '34.53%'}], position: 2600, duration: 67 },
            { id: "eid1055", tween: [ "style", "${_marketCoord2}", "left", '33.64%', { fromValue: '32.81%'}], position: 2667, duration: 66 },
            { id: "eid938", tween: [ "style", "${_marketCoord4}", "left", '44.92%', { fromValue: '40.19%'}], position: 600, duration: 400 },
            { id: "eid947", tween: [ "style", "${_marketCoord4}", "left", '6.64%', { fromValue: '44.92%'}], position: 1000, duration: 267 },
            { id: "eid978", tween: [ "style", "${_marketCoord4}", "left", '22.63%', { fromValue: '6.64%'}], position: 1533, duration: 200 },
            { id: "eid992", tween: [ "style", "${_marketCoord4}", "left", '24.54%', { fromValue: '22.63%'}], position: 1733, duration: 267 },
            { id: "eid1000", tween: [ "style", "${_marketCoord4}", "left", '28.21%', { fromValue: '24.54%'}], position: 2000, duration: 200 },
            { id: "eid1008", tween: [ "style", "${_marketCoord4}", "left", '37.32%', { fromValue: '28.21%'}], position: 2200, duration: 200 },
            { id: "eid1016", tween: [ "style", "${_marketCoord4}", "left", '42.42%', { fromValue: '37.32%'}], position: 2400, duration: 67 },
            { id: "eid1024", tween: [ "style", "${_marketCoord4}", "left", '56.34%', { fromValue: '42.42%'}], position: 2467, duration: 66 },
            { id: "eid1032", tween: [ "style", "${_marketCoord4}", "left", '61.47%', { fromValue: '56.34%'}], position: 2533, duration: 67 },
            { id: "eid1043", tween: [ "style", "${_marketCoord4}", "left", '62.5%', { fromValue: '61.47%'}], position: 2600, duration: 67 },
            { id: "eid1047", tween: [ "style", "${_marketCoord4}", "left", '60.62%', { fromValue: '62.5%'}], position: 2667, duration: 66 },
            { id: "eid932", tween: [ "style", "${_marketCoord3}", "left", '44.92%', { fromValue: '40.19%'}], position: 600, duration: 400 },
            { id: "eid949", tween: [ "style", "${_marketCoord3}", "left", '31.98%', { fromValue: '44.92%'}], position: 1000, duration: 267 },
            { id: "eid977", tween: [ "style", "${_marketCoord3}", "left", '32.81%', { fromValue: '31.98%'}], position: 1533, duration: 200 },
            { id: "eid990", tween: [ "style", "${_marketCoord3}", "left", '33.83%', { fromValue: '32.81%'}], position: 1733, duration: 267 },
            { id: "eid998", tween: [ "style", "${_marketCoord3}", "left", '35.87%', { fromValue: '33.83%'}], position: 2000, duration: 200 },
            { id: "eid1006", tween: [ "style", "${_marketCoord3}", "left", '40.31%', { fromValue: '35.87%'}], position: 2200, duration: 200 },
            { id: "eid1014", tween: [ "style", "${_marketCoord3}", "left", '42.42%', { fromValue: '40.31%'}], position: 2400, duration: 67 },
            { id: "eid1022", tween: [ "style", "${_marketCoord3}", "left", '49.32%', { fromValue: '42.42%'}], position: 2467, duration: 66 },
            { id: "eid1030", tween: [ "style", "${_marketCoord3}", "left", '52.17%', { fromValue: '49.32%'}], position: 2533, duration: 67 },
            { id: "eid1041", tween: [ "style", "${_marketCoord3}", "left", '52.34%', { fromValue: '52.17%'}], position: 2600, duration: 67 },
            { id: "eid1049", tween: [ "style", "${_marketCoord3}", "left", '54.59%', { fromValue: '52.34%'}], position: 2667, duration: 66 },
            { id: "eid928", tween: [ "style", "${_marketCoord1}", "opacity", '1', { fromValue: '1'}], position: 600, duration: 0 },
            { id: "eid943", tween: [ "style", "${_marketCoord1}", "opacity", '1', { fromValue: '1'}], position: 1000, duration: 0 },
            { id: "eid975", tween: [ "style", "${_marketCoord1}", "opacity", '1', { fromValue: '1'}], position: 1533, duration: 0 },
            { id: "eid1060", tween: [ "style", "${_marketCoord1}", "opacity", '0', { fromValue: '1'}], position: 2667, duration: 66 },
            { id: "eid941", tween: [ "style", "${_marketCoord2}", "top", '21.33%', { fromValue: '-19.32%'}], position: 600, duration: 400 },
            { id: "eid952", tween: [ "style", "${_marketCoord2}", "top", '58.19%', { fromValue: '21.33%'}], position: 1000, duration: 267 },
            { id: "eid983", tween: [ "style", "${_marketCoord2}", "top", '38.47%', { fromValue: '58.19%'}], position: 1533, duration: 200 },
            { id: "eid987", tween: [ "style", "${_marketCoord2}", "top", '31.94%', { fromValue: '38.47%'}], position: 1733, duration: 267 },
            { id: "eid995", tween: [ "style", "${_marketCoord2}", "top", '24.84%', { fromValue: '31.94%'}], position: 2000, duration: 200 },
            { id: "eid1003", tween: [ "style", "${_marketCoord2}", "top", '20.41%', { fromValue: '24.84%'}], position: 2200, duration: 200 },
            { id: "eid1011", tween: [ "style", "${_marketCoord2}", "top", '20%', { fromValue: '20.41%'}], position: 2400, duration: 67 },
            { id: "eid1019", tween: [ "style", "${_marketCoord2}", "top", '23.19%', { fromValue: '20%'}], position: 2467, duration: 66 },
            { id: "eid1027", tween: [ "style", "${_marketCoord2}", "top", '28.33%', { fromValue: '23.19%'}], position: 2533, duration: 67 },
            { id: "eid1035", tween: [ "style", "${_marketCoord2}", "top", '37.36%', { fromValue: '28.33%'}], position: 2600, duration: 67 },
            { id: "eid1056", tween: [ "style", "${_marketCoord2}", "top", '94.52%', { fromValue: '37.36%'}], position: 2667, duration: 66 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-80833650");
