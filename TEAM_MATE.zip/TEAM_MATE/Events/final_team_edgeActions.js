/***********************
* Adobe Edge Animate Composition Actions
*
* Edit this file with caution, being careful to preserve 
* function signatures and comments starting with 'Edge' to maintain the 
* ability to interact with these actions from within Adobe Edge Animate
*
***********************/
(function($, Edge, compId){
var Composition = Edge.Composition, Symbol = Edge.Symbol; // aliases for commonly used Edge classes

   //Edge symbol: 'stage'
   (function(symbolName) {
      
      
      

      

      

      

      

      

      Symbol.bindElementAction(compId, symbolName, "document", "compositionReady", function(sym, e) {
         sym.setVariable("current","");
         $("head").append('<link rel="stylesheet" type="text/css" href ="thecss.css"/>');
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_creat_btn2}", "click", function(sym, e) {
         var current = sym.getVariable("current");
         sym.play("out");
         //set the value of a Symbol variable
         sym.setVariable("current", "creat_btn2");

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_hospi_btn_1}", "click", function(sym, e) {
         var current = sym.getVariable("current");
         sym.play("out");
         //set the value of a Symbol variable
         sym.setVariable("current", "hospi_btn_1");
         

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_markt_btn}", "click", function(sym, e) {
         var current = sym.getVariable("current");
         sym.play("out");
         //set the value of a Symbol variable
         sym.setVariable("current", "markt_btn");

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_finan_btn}", "click", function(sym, e) {
         var current = sym.getVariable("current");
         sym.play("out");
         //set the value of a Symbol variable
         sym.setVariable("current", "finan_btn");

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_events_btn}", "click", function(sym, e) {
         var current = sym.getVariable("current");
         sym.play("out");
         //set the value of a Symbol variable
         sym.setVariable("current", "events_btn");

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_optrans_btn}", "click", function(sym, e) {
         var current = sym.getVariable("current");
         sym.play("out");
         //set the value of a Symbol variable
         sym.setVariable("current", "optrans_btn");

      });
      //Edge binding end

      Symbol.bindElementAction(compId, symbolName, "${_overall_btn}", "click", function(sym, e) {
         var current = sym.getVariable("current");
         sym.play("out");
         //set the value of a Symbol variable
         sym.setVariable("current", "overall_btn");

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 1933, function(sym, e) {
         sym.stop();

      });
      //Edge binding end

      Symbol.bindTriggerAction(compId, symbolName, "Default Timeline", 3733, function(sym, e) {
         var current = sym.getVariable("current");
         if(current=="creat_btn2"){
         window.open("../Creatives/index.html", "_self");
         }
         if(current=="hospi_btn_1"){
         window.open("../Hospi/index.html", "_self");
         }
         if(current=="markt_btn"){
         window.open("../Marketing/index.html", "_self");
         }
         if(current=="finan_btn"){
         window.open("../Finance/index.html", "_self");
         }
         if(current=="events_btn"){
         window.open("../Events/index.html", "_self");
         }
         if(current=="optrans_btn"){
         window.open("../OP/index.html", "_self");
         }
         if(current=="overall_btn"){
         window.open("../Overall_cod/index.html", "_self");
         }

      });
      //Edge binding end

   })("stage");
   //Edge symbol end:'stage'

})(jQuery, AdobeEdge, "EDGE-80833650");