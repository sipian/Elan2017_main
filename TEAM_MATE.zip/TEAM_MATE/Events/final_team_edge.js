/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.5.0",
   minimumCompatibleVersion: "1.5.0",
   build: "1.5.0.217",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'creat_btn2',
            type:'image',
            rect:['0%','6.1%','11.7%','6.3%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"creat_btn.png",'0px','0px']
         },
         {
            id:'hospi_btn_1',
            type:'image',
            rect:['0%','12.8%','11.7%','6.3%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"hospi_btn_1.png",'0px','0px']
         },
         {
            id:'markt_btn',
            type:'image',
            rect:['0%','19.7%','11.7%','6.3%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"markt_btn.png",'0px','0px']
         },
         {
            id:'finan_btn',
            type:'image',
            rect:['0%','26%','11.7%','6.3%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"finan_btn.png",'0px','0px']
         },
         {
            id:'events_btn',
            type:'image',
            rect:['0%','32.2%','11.7%','6.3%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"events_btn.png",'0px','0px']
         },
         {
            id:'optrans_btn',
            type:'image',
            rect:['0%','37.4%','11.7%','7.2%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"optrans_btn.png",'0px','0px']
         },
         {
            id:'overall_btn',
            type:'image',
            rect:['0%','43.9%','11.7%','7.2%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"overall_btn.png",'0px','0px']
         },
         {
            id:'biggieCoord2',
            type:'image',
            rect:['58.2%','30.3%','10.2%','18.1%','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"biggieCoord2.png",'0px','0px']
         },
         {
            id:'cultiCoord',
            type:'image',
            rect:['58.2%','30.3%','10.2%','18.1%','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"cultiCoord.png",'0px','0px']
         },
         {
            id:'eventsCore',
            type:'image',
            rect:['58.2%','30.3%','10.2%','18.1%','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"eventsCore.png",'0px','0px']
         },
         {
            id:'infiCoord',
            type:'image',
            rect:['58.2%','30.3%','10.2%','18.1%','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"infiCoord.png",'0px','0px']
         },
         {
            id:'litrCoord',
            type:'image',
            rect:['58.2%','30.3%','10.2%','18.1%','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"litrCoord.png",'0px','0px']
         },
         {
            id:'socialCoord',
            type:'image',
            rect:['58.2%','30.3%','10.2%','18.1%','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"socialCoord.png",'0px','0px']
         },
         {
            id:'techyCoord',
            type:'image',
            rect:['58.2%','30.3%','10.2%','18.1%','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"techyCoord.png",'0px','0px']
         },
         {
            id:'workshopCoord',
            type:'image',
            rect:['58.2%','30.3%','10.2%','18.1%','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"workshopCoord.png",'0px','0px']
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_eventsCore}": [
            ["style", "top", '-23.75%'],
            ["style", "opacity", '1'],
            ["style", "left", '43.91%']
         ],
         "${_hospi_btn_1}": [
            ["style", "top", '12.78%'],
            ["style", "height", '6.25%'],
            ["style", "left", '0%'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '11.72%']
         ],
         "${_optrans_btn}": [
            ["style", "top", '37.36%'],
            ["style", "height", '7.22%'],
            ["style", "left", '0%'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '11.72%']
         ],
         "${_workshopCoord}": [
            ["style", "top", '-23.75%'],
            ["style", "opacity", '1'],
            ["style", "left", '43.91%']
         ],
         "${_markt_btn}": [
            ["style", "top", '19.71%'],
            ["style", "height", '6.25%'],
            ["style", "left", '0%'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '11.72%']
         ],
         "${_overall_btn}": [
            ["style", "top", '43.88%'],
            ["style", "height", '7.22%'],
            ["style", "left", '0%'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '11.72%']
         ],
         "${_cultiCoord}": [
            ["style", "top", '-23.75%'],
            ["style", "opacity", '1'],
            ["style", "left", '43.91%']
         ],
         "${_biggieCoord2}": [
            ["style", "top", '-23.75%'],
            ["style", "opacity", '1'],
            ["style", "left", '43.91%']
         ],
         "${_events_btn}": [
            ["style", "top", '32.22%'],
            ["style", "height", '6.25%'],
            ["style", "left", '0%'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '11.72%']
         ],
         "${_finan_btn}": [
            ["style", "top", '25.97%'],
            ["style", "height", '6.25%'],
            ["style", "left", '0%'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '11.72%']
         ],
         "${_socialCoord}": [
            ["style", "top", '-23.75%'],
            ["style", "opacity", '1'],
            ["style", "left", '43.91%']
         ],
         "${_techyCoord}": [
            ["style", "top", '-23.75%'],
            ["style", "opacity", '1'],
            ["style", "left", '43.91%']
         ],
         "${_Stage}": [
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "min-width", '350px'],
            ["style", "overflow", 'hidden'],
            ["style", "height", '100%'],
            ["style", "width", '100%']
         ],
         "${_litrCoord}": [
            ["style", "top", '-23.75%'],
            ["style", "opacity", '1'],
            ["style", "left", '43.91%']
         ],
         "${_creat_btn2}": [
            ["style", "top", '6.11%'],
            ["style", "height", '6.25%'],
            ["style", "left", '0%'],
            ["style", "cursor", 'pointer'],
            ["style", "width", '11.72%']
         ],
         "${_infiCoord}": [
            ["style", "top", '-23.75%'],
            ["style", "opacity", '1'],
            ["style", "left", '43.91%']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 3733,
         autoPlay: true,
         labels: {
            "in": 200,
            "shortIn": 600,
            "out": 2200
         },
         timeline: [
            { id: "eid947", tween: [ "style", "${_litrCoord}", "left", '47.23%', { fromValue: '43.91%'}], position: 600, duration: 667 },
            { id: "eid963", tween: [ "style", "${_litrCoord}", "left", '3.4%', { fromValue: '47.27%'}], position: 1267, duration: 666 },
            { id: "eid1019", tween: [ "style", "${_litrCoord}", "left", '23.31%', { fromValue: '3.44%'}], position: 2200, duration: 200 },
            { id: "eid1031", tween: [ "style", "${_litrCoord}", "left", '36.78%', { fromValue: '23.28%'}], position: 2400, duration: 267 },
            { id: "eid1048", tween: [ "style", "${_litrCoord}", "left", '52.16%', { fromValue: '36.8%'}], position: 2667, duration: 200 },
            { id: "eid1060", tween: [ "style", "${_litrCoord}", "left", '67.7%', { fromValue: '52.19%'}], position: 2867, duration: 266 },
            { id: "eid1074", tween: [ "style", "${_litrCoord}", "left", '68.59%', { fromValue: '67.73%'}], position: 3133, duration: 267 },
            { id: "eid1088", tween: [ "style", "${_litrCoord}", "left", '46.17%', { fromValue: '68.59%'}], position: 3400, duration: 133 },
            { id: "eid1113", tween: [ "style", "${_litrCoord}", "left", '-11.72%', { fromValue: '46.17%'}], position: 3533, duration: 200 },
            { id: "eid940", tween: [ "style", "${_techyCoord}", "opacity", '1', { fromValue: '1'}], position: 600, duration: 0 },
            { id: "eid977", tween: [ "style", "${_techyCoord}", "opacity", '1', { fromValue: '1'}], position: 1933, duration: 0 },
            { id: "eid984", tween: [ "style", "${_techyCoord}", "opacity", '1', { fromValue: '1'}], position: 2200, duration: 0 },
            { id: "eid1109", tween: [ "style", "${_techyCoord}", "opacity", '0', { fromValue: '1'}], position: 3533, duration: 200 },
            { id: "eid937", tween: [ "style", "${_infiCoord}", "opacity", '1', { fromValue: '1'}], position: 600, duration: 0 },
            { id: "eid976", tween: [ "style", "${_infiCoord}", "opacity", '1', { fromValue: '1'}], position: 1933, duration: 0 },
            { id: "eid998", tween: [ "style", "${_infiCoord}", "opacity", '1', { fromValue: '1'}], position: 2200, duration: 0 },
            { id: "eid1039", tween: [ "style", "${_infiCoord}", "opacity", '1', { fromValue: '1'}], position: 2667, duration: 0 },
            { id: "eid1118", tween: [ "style", "${_infiCoord}", "opacity", '0', { fromValue: '1'}], position: 3533, duration: 200 },
            { id: "eid939", tween: [ "style", "${_socialCoord}", "opacity", '1', { fromValue: '1'}], position: 600, duration: 0 },
            { id: "eid979", tween: [ "style", "${_socialCoord}", "opacity", '1', { fromValue: '1'}], position: 1933, duration: 0 },
            { id: "eid987", tween: [ "style", "${_socialCoord}", "opacity", '1', { fromValue: '1'}], position: 2200, duration: 0 },
            { id: "eid1112", tween: [ "style", "${_socialCoord}", "opacity", '0', { fromValue: '1'}], position: 3533, duration: 200 },
            { id: "eid935", tween: [ "style", "${_eventsCore}", "opacity", '1', { fromValue: '1'}], position: 600, duration: 0 },
            { id: "eid973", tween: [ "style", "${_eventsCore}", "opacity", '1', { fromValue: '1'}], position: 1933, duration: 0 },
            { id: "eid995", tween: [ "style", "${_eventsCore}", "opacity", '1', { fromValue: '1'}], position: 2200, duration: 0 },
            { id: "eid1010", tween: [ "style", "${_eventsCore}", "opacity", '1', { fromValue: '1'}], position: 2400, duration: 0 },
            { id: "eid1121", tween: [ "style", "${_eventsCore}", "opacity", '0', { fromValue: '1'}], position: 3533, duration: 200 },
            { id: "eid943", tween: [ "style", "${_techyCoord}", "left", '47.23%', { fromValue: '43.91%'}], position: 600, duration: 667 },
            { id: "eid960", tween: [ "style", "${_techyCoord}", "left", '46.2%', { fromValue: '47.27%'}], position: 1267, duration: 666 },
            { id: "eid1017", tween: [ "style", "${_techyCoord}", "left", '73%', { fromValue: '46.17%'}], position: 2200, duration: 200 },
            { id: "eid1025", tween: [ "style", "${_techyCoord}", "left", '65.8%', { fromValue: '72.97%'}], position: 2400, duration: 267 },
            { id: "eid1042", tween: [ "style", "${_techyCoord}", "left", '48.44%', { fromValue: '65.78%'}], position: 2667, duration: 200 },
            { id: "eid1054", tween: [ "style", "${_techyCoord}", "left", '25.78%', { fromValue: '48.44%'}], position: 2867, duration: 266 },
            { id: "eid1068", tween: [ "style", "${_techyCoord}", "left", '20.7%', { fromValue: '25.78%'}], position: 3133, duration: 267 },
            { id: "eid1090", tween: [ "style", "${_techyCoord}", "left", '46.17%', { fromValue: '20.7%'}], position: 3400, duration: 133 },
            { id: "eid1108", tween: [ "style", "${_techyCoord}", "left", '51.25%', { fromValue: '46.17%'}], position: 3533, duration: 200 },
            { id: "eid944", tween: [ "style", "${_techyCoord}", "top", '10.69%', { fromValue: '-23.75%'}], position: 600, duration: 667 },
            { id: "eid959", tween: [ "style", "${_techyCoord}", "top", '42.08%', { fromValue: '10.69%'}], position: 1267, duration: 666 },
            { id: "eid1018", tween: [ "style", "${_techyCoord}", "top", '35.56%', { fromValue: '42.08%'}], position: 2200, duration: 200 },
            { id: "eid1026", tween: [ "style", "${_techyCoord}", "top", '6.94%', { fromValue: '35.56%'}], position: 2400, duration: 267 },
            { id: "eid1043", tween: [ "style", "${_techyCoord}", "top", '4.72%', { fromValue: '6.94%'}], position: 2667, duration: 200 },
            { id: "eid1055", tween: [ "style", "${_techyCoord}", "top", '9.17%', { fromValue: '4.72%'}], position: 2867, duration: 266 },
            { id: "eid1069", tween: [ "style", "${_techyCoord}", "top", '42.08%', { fromValue: '9.17%'}], position: 3133, duration: 267 },
            { id: "eid1091", tween: [ "style", "${_techyCoord}", "top", '42.78%', { fromValue: '42.08%'}], position: 3400, duration: 133 },
            { id: "eid1107", tween: [ "style", "${_techyCoord}", "top", '-23.63%', { fromValue: '42.78%'}], position: 3533, duration: 200 },
            { id: "eid933", tween: [ "style", "${_workshopCoord}", "opacity", '1', { fromValue: '1'}], position: 600, duration: 0 },
            { id: "eid974", tween: [ "style", "${_workshopCoord}", "opacity", '1', { fromValue: '1'}], position: 1933, duration: 0 },
            { id: "eid989", tween: [ "style", "${_workshopCoord}", "opacity", '1', { fromValue: '1'}], position: 2200, duration: 0 },
            { id: "eid1106", tween: [ "style", "${_workshopCoord}", "opacity", '0', { fromValue: '1'}], position: 3533, duration: 200 },
            { id: "eid941", tween: [ "style", "${_socialCoord}", "left", '47.23%', { fromValue: '43.91%'}], position: 600, duration: 667 },
            { id: "eid961", tween: [ "style", "${_socialCoord}", "left", '72.2%', { fromValue: '47.27%'}], position: 1267, duration: 666 },
            { id: "eid1015", tween: [ "style", "${_socialCoord}", "left", '63.5%', { fromValue: '72.19%'}], position: 2200, duration: 200 },
            { id: "eid1037", tween: [ "style", "${_socialCoord}", "left", '45.76%', { fromValue: '63.52%'}], position: 2400, duration: 267 },
            { id: "eid1040", tween: [ "style", "${_socialCoord}", "left", '25.78%', { fromValue: '45.78%'}], position: 2667, duration: 200 },
            { id: "eid1067", tween: [ "style", "${_socialCoord}", "left", '20.7%', { fromValue: '25.78%'}], position: 2867, duration: 266 },
            { id: "eid1080", tween: [ "style", "${_socialCoord}", "left", '29.52%', { fromValue: '20.7%'}], position: 3133, duration: 267 },
            { id: "eid1082", tween: [ "style", "${_socialCoord}", "left", '46.17%', { fromValue: '29.53%'}], position: 3400, duration: 133 },
            { id: "eid1110", tween: [ "style", "${_socialCoord}", "left", '11.72%', { fromValue: '46.17%'}], position: 3533, duration: 200 },
            { id: "eid949", tween: [ "style", "${_eventsCore}", "left", '47.23%', { fromValue: '43.91%'}], position: 600, duration: 667 },
            { id: "eid971", tween: [ "style", "${_eventsCore}", "left", '47.23%', { fromValue: '47.23%'}], position: 1933, duration: 0 },
            { id: "eid1009", tween: [ "style", "${_eventsCore}", "left", '46.17%', { fromValue: '47.27%'}], position: 2200, duration: 200 },
            { id: "eid1120", tween: [ "style", "${_eventsCore}", "left", '47.78%', { fromValue: '46.17%'}], position: 2400, duration: 267 },
            { id: "eid1129", tween: [ "style", "${_eventsCore}", "left", '46.38%', { fromValue: '47.78%'}], position: 2667, duration: 200 },
            { id: "eid1130", tween: [ "style", "${_eventsCore}", "left", '45.55%', { fromValue: '46.38%'}], position: 2867, duration: 266 },
            { id: "eid1132", tween: [ "style", "${_eventsCore}", "left", '46.14%', { fromValue: '45.55%'}], position: 3133, duration: 267 },
            { id: "eid1134", tween: [ "style", "${_eventsCore}", "left", '46.56%', { fromValue: '46.14%'}], position: 3400, duration: 133 },
            { id: "eid1136", tween: [ "style", "${_eventsCore}", "left", '33.17%', { fromValue: '46.56%'}], position: 3533, duration: 200 },
            { id: "eid934", tween: [ "style", "${_biggieCoord2}", "opacity", '1', { fromValue: '1'}], position: 600, duration: 0 },
            { id: "eid980", tween: [ "style", "${_biggieCoord2}", "opacity", '1', { fromValue: '1'}], position: 1933, duration: 0 },
            { id: "eid1002", tween: [ "style", "${_biggieCoord2}", "opacity", '1', { fromValue: '1'}], position: 2200, duration: 0 },
            { id: "eid1127", tween: [ "style", "${_biggieCoord2}", "opacity", '0', { fromValue: '1'}], position: 3533, duration: 200 },
            { id: "eid945", tween: [ "style", "${_cultiCoord}", "left", '47.23%', { fromValue: '43.91%'}], position: 600, duration: 667 },
            { id: "eid967", tween: [ "style", "${_cultiCoord}", "left", '58.28%', { fromValue: '47.27%'}], position: 1267, duration: 666 },
            { id: "eid1021", tween: [ "style", "${_cultiCoord}", "left", '44.92%', { fromValue: '58.28%'}], position: 2200, duration: 200 },
            { id: "eid1029", tween: [ "style", "${_cultiCoord}", "left", '61.6%', { fromValue: '44.92%'}], position: 2400, duration: 267 },
            { id: "eid1047", tween: [ "style", "${_cultiCoord}", "left", '69.42%', { fromValue: '61.56%'}], position: 2667, duration: 200 },
            { id: "eid1059", tween: [ "style", "${_cultiCoord}", "left", '68.2%', { fromValue: '69.45%'}], position: 2867, duration: 266 },
            { id: "eid1072", tween: [ "style", "${_cultiCoord}", "left", '47.97%', { fromValue: '68.2%'}], position: 3133, duration: 267 },
            { id: "eid1094", tween: [ "style", "${_cultiCoord}", "left", '46.17%', { fromValue: '47.97%'}], position: 3400, duration: 133 },
            { id: "eid1123", tween: [ "style", "${_cultiCoord}", "left", '67.35%', { fromValue: '46.17%'}], position: 3533, duration: 200 },
            { id: "eid956", tween: [ "style", "${_workshopCoord}", "top", '10.69%', { fromValue: '-23.75%'}], position: 600, duration: 667 },
            { id: "eid958", tween: [ "style", "${_workshopCoord}", "top", '42.08%', { fromValue: '10.69%'}], position: 1267, duration: 666 },
            { id: "eid1011", tween: [ "style", "${_workshopCoord}", "top", '21.55%', { fromValue: '42.08%'}], position: 2200, duration: 200 },
            { id: "eid1033", tween: [ "style", "${_workshopCoord}", "top", '42.08%', { fromValue: '21.53%'}], position: 2400, duration: 267 },
            { id: "eid1050", tween: [ "style", "${_workshopCoord}", "top", '73.33%', { fromValue: '42.08%'}], position: 2667, duration: 200 },
            { id: "eid1063", tween: [ "style", "${_workshopCoord}", "top", '75.14%', { fromValue: '73.33%'}], position: 2867, duration: 266 },
            { id: "eid1077", tween: [ "style", "${_workshopCoord}", "top", '55.39%', { fromValue: '75.14%'}], position: 3133, duration: 267 },
            { id: "eid1087", tween: [ "style", "${_workshopCoord}", "top", '42.81%', { fromValue: '55.42%'}], position: 3400, duration: 133 },
            { id: "eid1105", tween: [ "style", "${_workshopCoord}", "top", '-27.81%', { fromValue: '42.78%'}], position: 3533, duration: 200 },
            { id: "eid950", tween: [ "style", "${_eventsCore}", "top", '10.69%', { fromValue: '-23.75%'}], position: 600, duration: 667 },
            { id: "eid972", tween: [ "style", "${_eventsCore}", "top", '10.69%', { fromValue: '10.69%'}], position: 1933, duration: 0 },
            { id: "eid1008", tween: [ "style", "${_eventsCore}", "top", '42.08%', { fromValue: '10.69%'}], position: 2200, duration: 200 },
            { id: "eid1119", tween: [ "style", "${_eventsCore}", "top", '38.47%', { fromValue: '42.08%'}], position: 2400, duration: 267 },
            { id: "eid1128", tween: [ "style", "${_eventsCore}", "top", '35.56%', { fromValue: '38.47%'}], position: 2667, duration: 200 },
            { id: "eid1131", tween: [ "style", "${_eventsCore}", "top", '40.15%', { fromValue: '35.56%'}], position: 2867, duration: 266 },
            { id: "eid1133", tween: [ "style", "${_eventsCore}", "top", '42.08%', { fromValue: '40.15%'}], position: 3133, duration: 267 },
            { id: "eid1135", tween: [ "style", "${_eventsCore}", "top", '42.78%', { fromValue: '42.08%'}], position: 3400, duration: 133 },
            { id: "eid1137", tween: [ "style", "${_eventsCore}", "top", '101.88%', { fromValue: '42.78%'}], position: 3533, duration: 200 },
            { id: "eid942", tween: [ "style", "${_socialCoord}", "top", '10.69%', { fromValue: '-23.75%'}], position: 600, duration: 667 },
            { id: "eid962", tween: [ "style", "${_socialCoord}", "top", '42.08%', { fromValue: '10.69%'}], position: 1267, duration: 666 },
            { id: "eid1016", tween: [ "style", "${_socialCoord}", "top", '5.35%', { fromValue: '42.08%'}], position: 2200, duration: 200 },
            { id: "eid1038", tween: [ "style", "${_socialCoord}", "top", '1.67%', { fromValue: '5.42%'}], position: 2400, duration: 267 },
            { id: "eid1041", tween: [ "style", "${_socialCoord}", "top", '9.17%', { fromValue: '1.67%'}], position: 2667, duration: 200 },
            { id: "eid1066", tween: [ "style", "${_socialCoord}", "top", '40.97%', { fromValue: '9.17%'}], position: 2867, duration: 266 },
            { id: "eid1081", tween: [ "style", "${_socialCoord}", "top", '72.62%', { fromValue: '40.97%'}], position: 3133, duration: 267 },
            { id: "eid1083", tween: [ "style", "${_socialCoord}", "top", '42.08%', { fromValue: '72.64%'}], position: 3400, duration: 133 },
            { id: "eid1111", tween: [ "style", "${_socialCoord}", "top", '-23.61%', { fromValue: '42.08%'}], position: 3533, duration: 200 },
            { id: "eid953", tween: [ "style", "${_biggieCoord2}", "left", '47.23%', { fromValue: '43.91%'}], position: 600, duration: 667 },
            { id: "eid969", tween: [ "style", "${_biggieCoord2}", "left", '85.1%', { fromValue: '47.27%'}], position: 1267, duration: 666 },
            { id: "eid1023", tween: [ "style", "${_biggieCoord2}", "left", '68.59%', { fromValue: '85.08%'}], position: 2200, duration: 200 },
            { id: "eid1028", tween: [ "style", "${_biggieCoord2}", "left", '72.39%', { fromValue: '68.59%'}], position: 2400, duration: 267 },
            { id: "eid1044", tween: [ "style", "${_biggieCoord2}", "left", '68.69%', { fromValue: '72.42%'}], position: 2667, duration: 200 },
            { id: "eid1056", tween: [ "style", "${_biggieCoord2}", "left", '48.63%', { fromValue: '68.67%'}], position: 2867, duration: 266 },
            { id: "eid1070", tween: [ "style", "${_biggieCoord2}", "left", '26.95%', { fromValue: '48.59%'}], position: 3133, duration: 267 },
            { id: "eid1092", tween: [ "style", "${_biggieCoord2}", "left", '46.17%', { fromValue: '26.95%'}], position: 3400, duration: 133 },
            { id: "eid1125", tween: [ "style", "${_biggieCoord2}", "left", '83.75%', { fromValue: '46.17%'}], position: 3533, duration: 200 },
            { id: "eid954", tween: [ "style", "${_biggieCoord2}", "top", '10.69%', { fromValue: '-23.75%'}], position: 600, duration: 667 },
            { id: "eid970", tween: [ "style", "${_biggieCoord2}", "top", '72.22%', { fromValue: '10.69%'}], position: 1267, duration: 666 },
            { id: "eid1024", tween: [ "style", "${_biggieCoord2}", "top", '66.88%', { fromValue: '72.22%'}], position: 2200, duration: 200 },
            { id: "eid1027", tween: [ "style", "${_biggieCoord2}", "top", '40.97%', { fromValue: '66.94%'}], position: 2400, duration: 267 },
            { id: "eid1045", tween: [ "style", "${_biggieCoord2}", "top", '20.42%', { fromValue: '40.97%'}], position: 2667, duration: 200 },
            { id: "eid1057", tween: [ "style", "${_biggieCoord2}", "top", '4.72%', { fromValue: '20.42%'}], position: 2867, duration: 266 },
            { id: "eid1071", tween: [ "style", "${_biggieCoord2}", "top", '10.97%', { fromValue: '4.72%'}], position: 3133, duration: 267 },
            { id: "eid1093", tween: [ "style", "${_biggieCoord2}", "top", '42.78%', { fromValue: '10.97%'}], position: 3400, duration: 133 },
            { id: "eid1126", tween: [ "style", "${_biggieCoord2}", "top", '100%', { fromValue: '42.78%'}], position: 3533, duration: 200 },
            { id: "eid936", tween: [ "style", "${_cultiCoord}", "opacity", '1', { fromValue: '1'}], position: 600, duration: 0 },
            { id: "eid978", tween: [ "style", "${_cultiCoord}", "opacity", '1', { fromValue: '1'}], position: 1933, duration: 0 },
            { id: "eid1001", tween: [ "style", "${_cultiCoord}", "opacity", '1', { fromValue: '1'}], position: 2200, duration: 0 },
            { id: "eid1124", tween: [ "style", "${_cultiCoord}", "opacity", '0', { fromValue: '1'}], position: 3533, duration: 200 },
            { id: "eid951", tween: [ "style", "${_infiCoord}", "left", '47.23%', { fromValue: '43.91%'}], position: 600, duration: 667 },
            { id: "eid965", tween: [ "style", "${_infiCoord}", "left", '30.72%', { fromValue: '47.27%'}], position: 1267, duration: 666 },
            { id: "eid1013", tween: [ "style", "${_infiCoord}", "left", '41.09%', { fromValue: '30.7%'}], position: 2200, duration: 200 },
            { id: "eid1035", tween: [ "style", "${_infiCoord}", "left", '25.81%', { fromValue: '41.09%'}], position: 2400, duration: 267 },
            { id: "eid1052", tween: [ "style", "${_infiCoord}", "left", '20.7%', { fromValue: '25.78%'}], position: 2667, duration: 200 },
            { id: "eid1065", tween: [ "style", "${_infiCoord}", "left", '26.93%', { fromValue: '20.7%'}], position: 2867, duration: 266 },
            { id: "eid1078", tween: [ "style", "${_infiCoord}", "left", '49.09%', { fromValue: '26.95%'}], position: 3133, duration: 267 },
            { id: "eid1085", tween: [ "style", "${_infiCoord}", "left", '46.17%', { fromValue: '49.06%'}], position: 3400, duration: 133 },
            { id: "eid1116", tween: [ "style", "${_infiCoord}", "left", '5.23%', { fromValue: '46.17%'}], position: 3533, duration: 200 },
            { id: "eid955", tween: [ "style", "${_workshopCoord}", "left", '47.23%', { fromValue: '43.91%'}], position: 600, duration: 667 },
            { id: "eid957", tween: [ "style", "${_workshopCoord}", "left", '19.63%', { fromValue: '47.27%'}], position: 1267, duration: 666 },
            { id: "eid1012", tween: [ "style", "${_workshopCoord}", "left", '24.21%', { fromValue: '19.61%'}], position: 2200, duration: 200 },
            { id: "eid1034", tween: [ "style", "${_workshopCoord}", "left", '23.47%', { fromValue: '24.22%'}], position: 2400, duration: 267 },
            { id: "eid1051", tween: [ "style", "${_workshopCoord}", "left", '28.72%', { fromValue: '23.44%'}], position: 2667, duration: 200 },
            { id: "eid1062", tween: [ "style", "${_workshopCoord}", "left", '49.21%', { fromValue: '28.75%'}], position: 2867, duration: 266 },
            { id: "eid1076", tween: [ "style", "${_workshopCoord}", "left", '66.77%', { fromValue: '49.22%'}], position: 3133, duration: 267 },
            { id: "eid1086", tween: [ "style", "${_workshopCoord}", "left", '46.17%', { fromValue: '66.8%'}], position: 3400, duration: 133 },
            { id: "eid1104", tween: [ "style", "${_workshopCoord}", "left", '83.72%', { fromValue: '46.17%'}], position: 3533, duration: 200 },
            { id: "eid952", tween: [ "style", "${_infiCoord}", "top", '10.69%', { fromValue: '-23.75%'}], position: 600, duration: 667 },
            { id: "eid966", tween: [ "style", "${_infiCoord}", "top", '72.22%', { fromValue: '10.69%'}], position: 1267, duration: 666 },
            { id: "eid1014", tween: [ "style", "${_infiCoord}", "top", '0.97%', { fromValue: '72.22%'}], position: 2200, duration: 200 },
            { id: "eid1036", tween: [ "style", "${_infiCoord}", "top", '9.17%', { fromValue: '0.97%'}], position: 2400, duration: 267 },
            { id: "eid1053", tween: [ "style", "${_infiCoord}", "top", '40.97%', { fromValue: '9.17%'}], position: 2667, duration: 200 },
            { id: "eid1064", tween: [ "style", "${_infiCoord}", "top", '69.83%', { fromValue: '40.97%'}], position: 2867, duration: 266 },
            { id: "eid1079", tween: [ "style", "${_infiCoord}", "top", '79.59%', { fromValue: '69.86%'}], position: 3133, duration: 267 },
            { id: "eid1084", tween: [ "style", "${_infiCoord}", "top", '42.08%', { fromValue: '79.58%'}], position: 3400, duration: 133 },
            { id: "eid1117", tween: [ "style", "${_infiCoord}", "top", '100%', { fromValue: '42.08%'}], position: 3533, duration: 200 },
            { id: "eid938", tween: [ "style", "${_litrCoord}", "opacity", '1', { fromValue: '1'}], position: 600, duration: 0 },
            { id: "eid975", tween: [ "style", "${_litrCoord}", "opacity", '1', { fromValue: '1'}], position: 1933, duration: 0 },
            { id: "eid1007", tween: [ "style", "${_litrCoord}", "opacity", '1', { fromValue: '1'}], position: 2200, duration: 0 },
            { id: "eid1115", tween: [ "style", "${_litrCoord}", "opacity", '0', { fromValue: '1'}], position: 3533, duration: 200 },
            { id: "eid948", tween: [ "style", "${_litrCoord}", "top", '10.69%', { fromValue: '-23.75%'}], position: 600, duration: 667 },
            { id: "eid964", tween: [ "style", "${_litrCoord}", "top", '72.16%', { fromValue: '10.69%'}], position: 1267, duration: 666 },
            { id: "eid1020", tween: [ "style", "${_litrCoord}", "top", '54.31%', { fromValue: '72.22%'}], position: 2200, duration: 200 },
            { id: "eid1032", tween: [ "style", "${_litrCoord}", "top", '73.78%', { fromValue: '54.31%'}], position: 2400, duration: 267 },
            { id: "eid1049", tween: [ "style", "${_litrCoord}", "top", '76.63%', { fromValue: '73.75%'}], position: 2667, duration: 200 },
            { id: "eid1061", tween: [ "style", "${_litrCoord}", "top", '59.03%', { fromValue: '76.67%'}], position: 2867, duration: 266 },
            { id: "eid1075", tween: [ "style", "${_litrCoord}", "top", '21.39%', { fromValue: '59.03%'}], position: 3133, duration: 267 },
            { id: "eid1089", tween: [ "style", "${_litrCoord}", "top", '42.78%', { fromValue: '21.39%'}], position: 3400, duration: 133 },
            { id: "eid1114", tween: [ "style", "${_litrCoord}", "top", '44.58%', { fromValue: '42.78%'}], position: 3533, duration: 200 },
            { id: "eid946", tween: [ "style", "${_cultiCoord}", "top", '10.69%', { fromValue: '-23.75%'}], position: 600, duration: 667 },
            { id: "eid968", tween: [ "style", "${_cultiCoord}", "top", '72.22%', { fromValue: '10.69%'}], position: 1267, duration: 666 },
            { id: "eid1022", tween: [ "style", "${_cultiCoord}", "top", '78.19%', { fromValue: '72.22%'}], position: 2200, duration: 200 },
            { id: "eid1030", tween: [ "style", "${_cultiCoord}", "top", '73.75%', { fromValue: '78.19%'}], position: 2400, duration: 267 },
            { id: "eid1046", tween: [ "style", "${_cultiCoord}", "top", '55.34%', { fromValue: '73.75%'}], position: 2667, duration: 200 },
            { id: "eid1058", tween: [ "style", "${_cultiCoord}", "top", '24.03%', { fromValue: '55.28%'}], position: 2867, duration: 266 },
            { id: "eid1073", tween: [ "style", "${_cultiCoord}", "top", '3.33%', { fromValue: '24.03%'}], position: 3133, duration: 267 },
            { id: "eid1095", tween: [ "style", "${_cultiCoord}", "top", '42.08%', { fromValue: '3.33%'}], position: 3400, duration: 133 },
            { id: "eid1122", tween: [ "style", "${_cultiCoord}", "top", '104.58%', { fromValue: '42.08%'}], position: 3533, duration: 200 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-80833650");
