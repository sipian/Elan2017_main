/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.5.0",
   minimumCompatibleVersion: "1.5.0",
   build: "1.5.0.217",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'creat_btn2',
            type:'image',
            rect:['0%','6.1%','11.7%','6.3%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"creat_btn.png",'0px','0px']
         },
         {
            id:'hospi_btn_1',
            type:'image',
            rect:['0%','12.8%','11.7%','6.3%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"hospi_btn_1.png",'0px','0px']
         },
         {
            id:'markt_btn',
            type:'image',
            rect:['0%','19.7%','11.7%','6.3%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"markt_btn.png",'0px','0px']
         },
         {
            id:'finan_btn',
            type:'image',
            rect:['0%','26%','11.7%','6.3%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"finan_btn.png",'0px','0px']
         },
         {
            id:'events_btn',
            type:'image',
            rect:['0%','32.2%','11.7%','6.3%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"events_btn.png",'0px','0px']
         },
         {
            id:'optrans_btn',
            type:'image',
            rect:['0%','37.4%','11.7%','7.2%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"optrans_btn.png",'0px','0px']
         },
         {
            id:'overall_btn',
            type:'image',
            rect:['0%','43.9%','11.7%','7.2%','auto','auto'],
            cursor:['pointer'],
            fill:["rgba(0,0,0,0)",im+"overall_btn.png",'0px','0px']
         },
         {
            id:'overallCoord',
            type:'image',
            rect:['45.5%','33.1%','10.2%','18.1%','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"overallCoord.png",'0px','0px']
         },
         {
            id:'Text',
            type:'text',
            rect:['565px','396px','auto','auto','auto','auto'],
            text:"Surendra Chowhan<br>surendra@elan.org.in",
            font:['Arial, Helvetica, sans-serif',24,"rgba(0,0,0,1)","normal","none",""]
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_overall_btn}": [
            ["style", "top", '43.88%'],
            ["style", "height", '7.22%'],
            ["style", "cursor", 'pointer'],
            ["style", "left", '0%'],
            ["style", "width", '11.72%']
         ],
         "${_finan_btn}": [
            ["style", "top", '25.97%'],
            ["style", "height", '6.25%'],
            ["style", "cursor", 'pointer'],
            ["style", "left", '0%'],
            ["style", "width", '11.72%']
         ],
         "${_markt_btn}": [
            ["style", "top", '19.71%'],
            ["style", "height", '6.25%'],
            ["style", "cursor", 'pointer'],
            ["style", "left", '0%'],
            ["style", "width", '11.72%']
         ],
         "${_events_btn}": [
            ["style", "top", '32.22%'],
            ["style", "height", '6.25%'],
            ["style", "cursor", 'pointer'],
            ["style", "left", '0%'],
            ["style", "width", '11.72%']
         ],
         "${_Text}": [
            ["style", "top", '396px'],
            ["style", "opacity", '0'],
            ["style", "left", '565px']
         ],
         "${_Stage}": [
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "min-width", '350px'],
            ["style", "overflow", 'hidden'],
            ["style", "height", '100%'],
            ["style", "width", '100%']
         ],
         "${_overallCoord}": [
            ["style", "top", '33.06%'],
            ["style", "height", '3.19%'],
            ["style", "opacity", '0'],
            ["style", "left", '45.49%'],
            ["style", "width", '1.8%']
         ],
         "${_hospi_btn_1}": [
            ["style", "top", '12.78%'],
            ["style", "height", '6.25%'],
            ["style", "cursor", 'pointer'],
            ["style", "left", '0%'],
            ["style", "width", '11.72%']
         ],
         "${_creat_btn2}": [
            ["style", "top", '6.11%'],
            ["style", "height", '6.25%'],
            ["style", "cursor", 'pointer'],
            ["style", "left", '0%'],
            ["style", "width", '11.72%']
         ],
         "${_optrans_btn}": [
            ["style", "top", '37.36%'],
            ["style", "height", '7.22%'],
            ["style", "cursor", 'pointer'],
            ["style", "left", '0%'],
            ["style", "width", '11.72%']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 1933,
         autoPlay: true,
         labels: {
            "in": 200,
            "shortIn": 600,
            "out": 1533
         },
         timeline: [
            { id: "eid920", tween: [ "style", "${_overallCoord}", "width", '1.8%', { fromValue: '1.8%'}], position: 600, duration: 0 },
            { id: "eid922", tween: [ "style", "${_overallCoord}", "width", '4.38%', { fromValue: '1.8%'}], position: 733, duration: 0 },
            { id: "eid925", tween: [ "style", "${_overallCoord}", "width", '8.44%', { fromValue: '4.38%'}], position: 933, duration: 0 },
            { id: "eid928", tween: [ "style", "${_overallCoord}", "width", '12.35%', { fromValue: '8.44%'}], position: 1133, duration: 0 },
            { id: "eid934", tween: [ "style", "${_overallCoord}", "width", '8.05%', { fromValue: '12.35%'}], position: 1533, duration: 0 },
            { id: "eid938", tween: [ "style", "${_overallCoord}", "width", '3.6%', { fromValue: '8.05%'}], position: 1733, duration: 0 },
            { id: "eid940", tween: [ "style", "${_overallCoord}", "width", '3.05%', { fromValue: '3.6%'}], position: 1933, duration: 0 },
            { id: "eid919", tween: [ "style", "${_overallCoord}", "opacity", '0', { fromValue: '0'}], position: 600, duration: 0 },
            { id: "eid924", tween: [ "style", "${_overallCoord}", "opacity", '0.32321166992188', { fromValue: '0'}], position: 733, duration: 0 },
            { id: "eid927", tween: [ "style", "${_overallCoord}", "opacity", '0.6303103864193', { fromValue: '0.32321166992188'}], position: 933, duration: 0 },
            { id: "eid930", tween: [ "style", "${_overallCoord}", "opacity", '1', { fromValue: '0.6303103864193'}], position: 1133, duration: 0 },
            { id: "eid933", tween: [ "style", "${_overallCoord}", "opacity", '1', { fromValue: '1'}], position: 1400, duration: 0 },
            { id: "eid936", tween: [ "style", "${_overallCoord}", "opacity", '0.755859375', { fromValue: '1'}], position: 1533, duration: 0 },
            { id: "eid939", tween: [ "style", "${_overallCoord}", "opacity", '0.35174524784088', { fromValue: '0.755859375'}], position: 1733, duration: 0 },
            { id: "eid942", tween: [ "style", "${_overallCoord}", "opacity", '0', { fromValue: '0.35174524784088'}], position: 1933, duration: 0 },
            { id: "eid918", tween: [ "style", "${_overallCoord}", "top", '33.06%', { fromValue: '33.06%'}], position: 600, duration: 0 },
            { id: "eid932", tween: [ "style", "${_overallCoord}", "top", '33.06%', { fromValue: '33.06%'}], position: 1400, duration: 0 },
            { id: "eid921", tween: [ "style", "${_overallCoord}", "height", '3.19%', { fromValue: '3.19%'}], position: 600, duration: 0 },
            { id: "eid923", tween: [ "style", "${_overallCoord}", "height", '7.78%', { fromValue: '3.19%'}], position: 733, duration: 0 },
            { id: "eid926", tween: [ "style", "${_overallCoord}", "height", '15%', { fromValue: '7.78%'}], position: 933, duration: 0 },
            { id: "eid929", tween: [ "style", "${_overallCoord}", "height", '21.94%', { fromValue: '15%'}], position: 1133, duration: 0 },
            { id: "eid935", tween: [ "style", "${_overallCoord}", "height", '14.31%', { fromValue: '21.94%'}], position: 1533, duration: 0 },
            { id: "eid937", tween: [ "style", "${_overallCoord}", "height", '6.53%', { fromValue: '14.31%'}], position: 1733, duration: 0 },
            { id: "eid941", tween: [ "style", "${_overallCoord}", "height", '5%', { fromValue: '6.53%'}], position: 1933, duration: 0 },
            { id: "eid943", tween: [ "style", "${_Text}", "opacity", '0', { fromValue: '0'}], position: 600, duration: 0 },
            { id: "eid944", tween: [ "style", "${_Text}", "opacity", '0', { fromValue: '0'}], position: 933, duration: 0 },
            { id: "eid945", tween: [ "style", "${_Text}", "opacity", '1', { fromValue: '0'}], position: 1133, duration: 0 },
            { id: "eid946", tween: [ "style", "${_Text}", "opacity", '0', { fromValue: '1'}], position: 1533, duration: 0 },
            { id: "eid917", tween: [ "style", "${_overallCoord}", "left", '45.49%', { fromValue: '45.49%'}], position: 600, duration: 0 },
            { id: "eid931", tween: [ "style", "${_overallCoord}", "left", '45.49%', { fromValue: '45.49%'}], position: 1400, duration: 0 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-80833650");
